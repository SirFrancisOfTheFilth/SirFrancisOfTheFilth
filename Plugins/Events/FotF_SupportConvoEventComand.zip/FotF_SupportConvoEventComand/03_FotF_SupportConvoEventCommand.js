/*--------------------------------------------------------------------------
This plugin is a modification of MarkyJoe's Selector Event Commands:

https://github.com/MarkyJoe1990/SRPG-Studio/tree/master/Plugin/Event%20Commands/Selector-Event-Commands-REVAMP

It contains all the functionality of his plugin with the addition of a new
custom event command: SupportConvo (can be changed in this file's settings)

The SupportConvo event command also works in a very similar way to a selector
event command. Exceptions are that var1 and var2 are reserved for the unit ID
output, so if you use them, you don't get the unit's ID and index, but two unit
IDs instead. Also
IDs instead. Also

___________________________________________________________________________
						Ok, so what does it do?
___________________________________________________________________________

The event command is designed to be used as some sort of shortcut to easily
create and execute an event between two units. I'll call this an activity
or event from here on.

Think of this scenario:

After a fierce battle, the party enjoys some well-deserved downtime in their
base. There could be several pass-times to enjoy, like fishing or cooking
together, which would strengthen the bonds of the two involved units.
The player will be presented a customizable list of activities to choose from.

After selecting the activity, the player then has to select the first unit out
of the pool of allowed units (customizable). They are then presented with a
selection of units this unit still has uncompleted supports with. Selecting
a second unit will start the activity, displaying a text window with a pre-
written text.

Maybe you catch a fish or prepare a delicious meal? This event is able
to drop items, give out skills, exp and gold to one or both of the units.

It's possible to flip a self switch when canceling or another one when
completing the activity. This can be used to flip the switch for the afore-
mentioned support and other event commands.

___________________________________________________________________________
								Setup
___________________________________________________________________________

Before executing the event command, there are a few things you have to prepare
in advance. The first thing you should do is look at the settings section of 
this file and adjust everything there to your liking. Make sure to set/use the 
right tab of original data (tab 1 means setting it to 0).

___________________________________________________________________________
							Creating Events
___________________________________________________________________________

All possible events are stored in the original data tab you chose in settings.
To access original data, go to Database > Config > Original Data and find
your tab. There you can create and edit original data objects, which serve
as events the player can choose from later.

___________________________________________________________________________
							Setting up events
___________________________________________________________________________

The first thing you probably set is an event's name and description. The
name is displayed in the selector window along with the icon. The decription
is shown at the bottom of the screen for the event that's being hovered over.

To set the text that is displayed when the event is executed, go to the
original data object's custom parameters and define:

{
	eventText:"Your text here"
}

You can also use control characters, just not those that modify text font
or color. When doing this, you have to use two backslashes \\ instead of one,
because of how escape characters work here.

The number values control multiple things about the event:

Value 1: Number of items to give out as a reward (items specified elsewhere)
Value 2: Amount of exp given out
Value 3: Number of skills to give out as a reward (skills specified elsewhere)
Value 4: Which unit to give the skill(s) to (0 -> both; 1 -> unit1; 2 -> unit2)
Value 5: Which unit to give exp to (0 -> both; 1 -> unit1; 2 -> unit2)
Value 6: Amount of gold given out

Everything else is done via the Multiple Data dialog:

Unit:

Here you can either choose a list of units eligible to participate in the
event (Match all) or are prohibited from participating (Mismatch/Mismatch all).
For the latter, the list to subtract from is the list of all player units.

Weapon/Item:

These are handled together and all selected are thrown into a pool for
which you can define custom probabilities as an array like this and add
it to the custom parameters:

probability:[item1, item2, item3, ...]

where item1, item2, ... are numbers (please no negatives) that represent
the "weight" an item has in the pool. An item with weight 20 doesn't have
a 20% chance to drop, but rather has double the chance of dropping as an
item with weight 10. How many items are dropped can be set in value 1.
Items are dropped into the convoy for convenience. Don't forget the
separating commas when setting multiple custom parameters.

Skill:

Same as with items, just that it gives skills. How many is controlled by
value 3, which unit recieves them by value 4.

___________________________________________________________________________
						The event command itself
___________________________________________________________________________


Now that you have some events to select from, you are ready to set up a
convo event. This is done via the Execute Script event command set to
"Call Event Command" with the event command name being "SupportConvo" (or what-
ever you set it to in the settings). In the "Property" prompt, you can
add some optional parameters in curly braces {}:

{
	var1:'VariableName1'		//Name of the variable unit1's ID is saved to, case sensitive
	var2:'VariableName2'		//Name of the variable unit2's ID is saved to, case sensitive
	maxCount:4,					//Maximum number of events to choose from
	selfSwitch:'a',				//Self switch to activate if the event is canceled. Canceling is disabled if this is not defined.
	selfSwitch2:'b',			//Self switch to activate if the event is completed successfully
	eventIdList:[1,2,7,...],	//List of event IDs to include, respects maxCount, can be randomized with isEventRandom
	isEventRandom:true			//Whether events chosen are picked at random or in order until maxCount is reached
}

___________________________________________________________________________
						How to use the outputs
___________________________________________________________________________

When the event command ends, there are 5 possible outputs, which have been
defined in the properties of the event command, depending on if the command
was completed or canceled.

If completed:

	var1: Unit1's ID will be set to this variable
	var2: Unit2's ID will be set to this variable
	var3: ID of the event that has been completed
	selfSwitch2: This self switch will be flipped

If canceled:

	selfSwitch: This self switch will be flipped
	
With this you can define what happens after the event. For example, you can
set up events to flip the right switch to activate a support between the two
units the player selected. You could also increase the unit's stats depending
on the type of event that was selected. The cancel switch allows you to control
if the player is allowed to cancel the event and can also be used for further
event commands.

Unfortunately it's impossible at this point in time to get the switch from
the supportData object directly without looping over every switch and trying
them out one by one. So you'll have to do some eventing to find the right
switch, sorry :(

_____________________________________________________________________________
								EPILOGUE
_____________________________________________________________________________

If you have any questions about this plugin, feel free to reach out to me
over the SRPG Studio University Discord server @SirFrancisoftheFilth

Big thanks to Raguna for commissioning this plugin and making it publicly available!
  
Original Plugin Author:
Francis of the Filth
  
2024/10/09
Released
--------------------------------------------------------------------------*/


var FotF_SupportConvoSettings = {
	EventCommandName:'SupportConvo',					//
	OriginalDataEvent:1,								//Tab of original data to choose events from (starts at 0, so 1 here is actually 2 in game)
	EventWindowTitle:'Select Event',					//Event select window title, '' for no title (title scroll will disappear too)
	ConvoWindowTitle:'Activity',						//Convo window title, '' for no title (title scroll will disappear too)
	WindowWidth:460,									//Convo window width
	WindowHeight:140,									//Convo window height
	WindowOffsetX:0,									//How far the convo window is drawn from the middle of the screen (+ is right)
	WindowOffsetY:0,									//How far the convo window is drawn from the middle of the screen (+ is down)
	TextColor:0xFFFFFF,									//Text color of the convo text
	FontId:0											//ID of the font used for the convo text
};

var FotF_SupportConvoMode = {
	EVENTSELECT:0,
	UNITSELECT:1,
	TARGETSELECT:2,
	DISPLAY:3,
	RESULT:4,
	NONE:5
};

//Hope no one actually adds new object types with ID 69 or this will be VERY hard to debug lol.
//If you suspect this is causing incompatibilities (it is 99.9999% not), change it to something else, like 420.
ObjectType.GOLD = 69;

//These are not really neccessary, but I thought it would be nice for a change to get a random weird message instead of an error.
//You can add and remove them as you like, but there needs to be at least one (can be empty) and they all have to be strings.
//They can even process the same pseudo- and normal control characters as the custom parameters of the original data events.
var FotF_EmergencyConvos = [
	"{u1} and {u2} went on a long walk and talked about the inevitable heat death of the universe.",
	"{u1} and {u2} checked their balance. It's \\G. Is that a lot you ask? Heck do I know, I'm just a pre-written string with a control character inside.",
	"Did you know you can use control characters in the event text? Though not all are supported.",
	"\\pdb[0] is the name of the first player unit in your project's database. How I know this? I AM IN YOUR WALLS!",
	"Did you know that the chicken came before the egg, according to the Bible. However scientifically speaking, the egg should have been there first.",
	"Your ad could be here!",
	"Go set the text for this event you lazy ass!",
	"AMOGUS"
];

(function() {
	var FotF_AppendConvoEvent = ScriptExecuteEventCommand._configureOriginalEventCommand;
    ScriptExecuteEventCommand._configureOriginalEventCommand = function(groupArray) {
        FotF_AppendConvoEvent.call(this, groupArray);
        groupArray.appendObject(FotF_SupportConvoSelector);
    };
	
	var FotF_PushAdditionalSelectorObjects = SelectorEventControl._configureSelectorDataArray;
	SelectorEventControl._configureSelectorDataArray = function(groupArray) {
        FotF_PushAdditionalSelectorObjects.call(this, groupArray);
		groupArray.push(SelectorData.ConvoEventData);
		groupArray.push(SelectorData.ConvoUnit);
		groupArray.push(SelectorData.ConvoTarget);
    };
	
})();

var FotF_SupportConvoSelector = defineObject(BaseEventCommand, {
	
	_event: null,
	_unit1: null,
	_unit2: null,
	_var1: null,
	_var2: null,
	_mode: null,
	_itemArray: null,
	_skillArray: null,
	_convoWindow: null,
	_messageView: null,
	_messageViewParam: null,
	_dynamicEvent: null,
	_isDynamicEvent: null,
	_eventWaitChain: null,
	
	enterEventCommandCycle: function() {
		this._isForceEnd = false;
		this._isDynamicEvent = false;
		this._itemArray = [];
		this._skillArray = [];
		this._eventWaitChain = [];
		this._dynamicEvent = createObject(DynamicEvent);

		this._args = root.getEventCommandObject().getEventCommandArgument();
		if (this._args == undefined) {
			root.msg("Please define arguments for this selector event.");
			return EnterResult.NOTENTER;
		}
		
		var var1String = this._args.var1;
		if (typeof var1String == "string") {
			this._var1 = SelectorEventControl.parseVariableString(var1String);
			if (this._var1 == null) {
				root.msg("It seems you wanted to use a variable, but nothing in the database matched its name. Check the variable name you specified and confirm that it matches the variable you want to use in the database. Remember, it's case sensitive!");
				return EnterResult.NOTENTER;
			}
		} else {
			this._var1 = null;
		}
		
		var var2String = this._args.var2;
		if (typeof var2String == "string") {
			this._var2 = SelectorEventControl.parseVariableString(var2String);
			if (this._var2 == null) {
				root.msg("It seems you wanted to use a second variable, but nothing in the database matched its name. Check the variable name you specified and confirm that it matches the variable you want to use in the database. Remember, it's case sensitive!");
				return EnterResult.NOTENTER;
			}
		} else {
			this._var2 = null;
		}
		
		var var3String = this._args.var3;
		if (typeof var3String == "string") {
			this._var3 = SelectorEventControl.parseVariableString(var3String);
			if (this._var3 == null) {
				root.msg("It seems you wanted to use a second variable, but nothing in the database matched its name. Check the variable name you specified and confirm that it matches the variable you want to use in the database. Remember, it's case sensitive!");
				return EnterResult.NOTENTER;
			}
		} else {
			this._var3 = null;
		}

		// Data Type. Required.
		this._dataType = 'convodata';
		if (typeof this._dataType != "string") {
			root.msg("The variable you wanted to use could not be found. Check the variable name you specified and confirm that it matches the variable you want to use in the database. Remember, it's case sensitive!");
			return EnterResult.NOTENTER;
		}

		this._selectData = SelectorEventControl.createSelectorData(this._dataType);
		if (this._selectData == null) {
			root.msg("The data type you specified could not be found. Please check that the data type name is correct and that it is included in the Selector Event Control configuration array.");
			return EnterResult.NOTENTER;
		}

		// Data List. Required most of the time, but will sometimes have a default set.
		if (typeof this._args.maxCount === 'number') {
			var goalLength = this._args.maxCount;
		} else {
			var goalLength = root.getBaseData().getOriginalDataList(FotF_SupportConvoSettings.OriginalDataEvent).getCount();
		}
		
		if (typeof this._args.isEventRandom === 'boolean' && this._args.isEventRandom === true) {
			var isRandomized = true;
		} else {
			var isRandomized = false;
		}
		
		if (typeof this._args.eventIdList !== 'undefined') {
			var dataList = SelectorEventControl.getOriginalDataListFromIdArray(this._args.eventIdList, FotF_SupportConvoSettings.OriginalDataEvent, isRandomized, goalLength)
		} else {
			var i;
			var idArray = [];
			for (i = 0; i < goalLength; i++) {
				idArray.push(i);
			}
			var dataList = SelectorEventControl.getOriginalDataListFromIdArray(idArray, FotF_SupportConvoSettings.OriginalDataEvent, isRandomized, goalLength)
		}
		
		var dataListType = typeof dataList;
		if (dataListType === "function") {
			this._dataList = dataList();
		} else if (dataListType === "undefined")  {
			this._dataList = this._selectData.getSessionDataList();
		} else {
			this._dataList = dataList;
		}

		if (this._dataList == undefined) {
			root.msg("You need to specify a data list for this event.");
			return EnterResult.NOTENTER;
		}
		this._selectData.setData(this._unit, this._dataList);

		this._unit = null;
		var sceneType = root.getBaseScene();
		if (sceneType === SceneType.FREE) {
			//this._unit = root.getCurrentSession().getActiveEventUnit();
		}

		this._maxCount = this._args.maxCount;
		if (this._maxCount == undefined) {
			this._maxCount = this._dataList.getCount();
		}

		this._rerollCallback = this._args.rerollCallback;
		var isSetReroll = this._maxCount < this._dataList.getCount();
		this._reroll(isSetReroll);

		// Self Switch
		var selfSwitch = this._args.selfSwitch;
		var selfSwitchType = typeof selfSwitch;
		if (selfSwitchType == "number") {
			this._selfSwitch = selfSwitch;
		} else if (selfSwitchType == "string") {
			this._selfSwitch = SelectorEventControl.parseSelfSwitchString(selfSwitch);
		} else {
			this._selfSwitch = -1;
		}
		
		var selfSwitch2 = this._args.selfSwitch2;
		var selfSwitchType2 = typeof selfSwitch2;
		if (selfSwitchType2 == "number") {
			this._selfSwitch2 = selfSwitch2;
		} else if (selfSwitchType2 == "string") {
			this._selfSwitch2 = SelectorEventControl.parseSelfSwitchString(selfSwitch2);
		} else {
			this._selfSwitch2 = -1;
		}
		
		this._mode = FotF_SupportConvoMode.EVENTSELECT;

		return EnterResult.OK;
	},
	
	moveEventCommandCycle: function() {	
		var mode;
		
		if (this._mode !== FotF_SupportConvoMode.DISPLAY && this._mode !== FotF_SupportConvoMode.RESULT) {
			if (this._selectData.getSelectorDataName() === 'convodata') {
				mode = FotF_SupportConvoMode.EVENTSELECT;
			} else if (this._selectData.getSelectorDataName() === 'convounit') {
				mode = FotF_SupportConvoMode.UNITSELECT;
			} else if (this._selectData.getSelectorDataName() === 'targetunit') {
				mode = FotF_SupportConvoMode.TARGETSELECT;
			} else {
				mode = FotF_SupportConvoMode.NONE;
			}
			
			if (this._mode !== mode) {
				this.changeSelectorMode(mode);
			}
		}
		
		var result = this._selectData.moveSelectorData();
		//EventSchedulerControl.setEnabled(true);

		if (InputControl.isOptionAction2() || this._isClickingRerollWindow()) {
			if (Math.ceil(this._dataList.getCount() / this._maxCount) != 0) {
				MediaControl.soundDirect("commandselect");
				this._reroll(true);
			} else {
				MediaControl.soundDirect("operationblock");
			}
		}
		
		if (this._mode === FotF_SupportConvoMode.DISPLAY && (InputControl.isSelectAction() || InputControl.isCancelAction())) {
			this.changeSelectorMode(FotF_SupportConvoMode.RESULT);
			
			if (this._var1 !== null) {
				var table = this._var1.table;
				var index = this._var1.index;
				var ID = this._unit1.getId();
				root.getMetaSession().getVariableTable(table).setVariable(index, ID);
			}
			
			if (this._var2 !== null) {
				var table = this._var2.table;
				var index = this._var2.index;
				var ID = this._unit2.getId();
				root.getMetaSession().getVariableTable(table).setVariable(index, ID);
			}
			
			if (this._var3 !== null) {
				var table = this._var3.table;
				var index = this._var3.index;
				var ID = this._event.getId();
				root.getMetaSession().getVariableTable(table).setVariable(index, ID);
			}
			
			this.executeConvoEvent();
		}
		
		if (this._mode === FotF_SupportConvoMode.RESULT) {
			var generator = this._dynamicEvent.acquireEventGenerator();
			var result2 = this._dynamicEvent.moveDynamicEvent();
		
			if (this._isDynamicEvent === true && result2 === MoveResult.END) {
				if (this._eventWaitChain.length > 0) {
					if (this._eventWaitChain[0][0] === ObjectType.ITEM) {
						generator.stockItemChange(this._eventWaitChain[0][1], this._eventWaitChain[0][2], false);
					} else if (this._eventWaitChain[0][0] === ObjectType.UNIT) {
						generator.experiencePlus(this._eventWaitChain[0][1], this._eventWaitChain[0][2], false);
					} else if (this._eventWaitChain[0][0] === ObjectType.SKILL) {
						generator.skillChange(this._eventWaitChain[0][3], this._eventWaitChain[0][1], this._eventWaitChain[0][2], false);
					} else if (this._eventWaitChain[0][0] === ObjectType.GOLD) {
						generator.goldChange(this._eventWaitChain[0][2], this._eventWaitChain[0][1], false);
					}
					this._eventWaitChain.splice(0, 1);
					this._dynamicEvent.executeDynamicEvent();
					return MoveResult.CONTINUE;
				} else {
					UnitEventChecker.setCancelFlag(true);
					if (this._selfSwitch2 != -1) {
						root.setSelfSwitch(this._selfSwitch2, true);
					}
					//MediaControl.soundDirect('commandcancel');
					return MoveResult.END;
				}
			}
			
			return MoveResult.CONTINUE;
		}

		if (this._isForceEnd == true) {
			return MoveResult.END;
		}

		if (result == MoveResult.SELECT) {	
			if (this._mode === FotF_SupportConvoMode.EVENTSELECT) {
				this._event = this._selectData.getObject();
				var activityText = this._event.custom.eventText;
				
				if (typeof activityText !== 'string') {
					var count = FotF_EmergencyConvos.length;
					var random = Math.floor((root.getRandomNumber() / 32768) * count);
					activityText = FotF_EmergencyConvos[random];
				}
				
				this._messageViewParam = StructureBuilder.buildMessageViewParam();		
				this._messageViewParam.messageLayout = root.getDefaultMessageLayout(MessageLayout.CENTER);
				this._messageViewParam.text = activityText;
				
				if (this._messageViewParam.text === null) {
					this._messageViewParam.text = '';
				}				
				this._messageView = createObject(FotF_ConvoMessageView);
				this._convoWindow = createObject(FotF_ConvoWindow);
				
				this._messageView.setupMessageView(this._messageViewParam, this._convoWindow.getWindowTextUI());
				this._messageView._containerArray = this._messageView._messageAnalyzer.getCoreAnalyzer().createTextContainerArray();
				this._messageView._messageAnalyzer.getCoreAnalyzer().setTextLineArray(this._messageView._containerArray[0]);

				var list = this.getFilteredUnitList(this._event);
				var finalList = this.getConvoUnitList(list);
				
				if (finalList.getCount() < 1) {
					root.msg('There are no support conversations left for these units');
					return MoveResult.END;
				}
				
				this._selectData = SelectorEventControl.createSelectorData("convoUnit");
				this._selectData.setData(this._unit, finalList);
				this.changeSelectorMode(FotF_SupportConvoMode.UNITSELECT);
			} else if (this._mode === FotF_SupportConvoMode.UNITSELECT) {
				this._unit1 = this._selectData.getObject();
				var list = this.getConvoList(this._unit1);
				this._selectData = SelectorEventControl.createSelectorData("targetUnit");
				this._selectData.setData(this._unit, list);
				this.changeSelectorMode(FotF_SupportConvoMode.TARGETSELECT);
			} else if (this._mode === FotF_SupportConvoMode.TARGETSELECT) {
				this._unit2 = this._selectData.getObject();
				this.changeSelectorMode(FotF_SupportConvoMode.DISPLAY);
			}
			return MoveResult.CONTINUE;
		} else if (result == MoveResult.CANCEL) {
			if (this._mode === FotF_SupportConvoMode.UNITSELECT || this._mode === FotF_SupportConvoMode.TARGETSELECT) {
				this.changeSelectorMode(FotF_SupportConvoMode.EVENTSELECT);
				this.enterEventCommandCycle();
				MediaControl.soundDirect('commandcancel');
			} else {
				if (this._selfSwitch != -1) {
					UnitEventChecker.setCancelFlag(true);
					root.setSelfSwitch(this._selfSwitch, true);
					MediaControl.soundDirect('commandcancel');
					return MoveResult.CANCEL;
				} else {
					MediaControl.soundDirect('operationblock');
				}
			}
		}

		return MoveResult.CONTINUE;
	},
	
	_isClickingRerollWindow: function() {
		return this._selectData.isClickingRerollWindow();
	},

	_reroll: function(isSetReroll) {
		var finalList = StructureBuilder.buildDataList();
		
		if (typeof this._dataList._arr !== 'undefined' && this._dataList._arr !== null) {
			var dataListChunk = this._dataList._arr.splice(0, this._maxCount);
		} else {
			var dataListChuck = this._dataList;
		}

		finalList.setDataArray(dataListChunk);
		this._selectData.setData(this._unit, finalList);

		if (isSetReroll === true) {
			this._selectData.setRerollCount(Math.ceil(this._dataList.getCount() / this._maxCount));
			if (this._rerollCallback != undefined) {
				this._rerollCallback.call(this);
			}
		}
	},

	_setVariable1: function(objectId) {
		var meta = root.getMetaSession();
		var variableTable = meta.getVariableTable(this._var1.table);
		variableTable.setVariable(this._var1.index, objectId);
	},

	_setVariable2: function(objectIndex) {
		var meta = root.getMetaSession();
		var variableTable = meta.getVariableTable(this._var2.table);
		variableTable.setVariable(this._var2.index, objectIndex);
	},

	drawEventCommandCycle: function() {
		if (this._mode === FotF_SupportConvoMode.DISPLAY) {
			this.drawConvo();
		} else if (this._mode !== FotF_SupportConvoMode.RESULT) {
			this._selectData.drawSelectorData();
		}
	},

    isEventCommandSkipAllowed: function() {
		return false;
	},

	getRerollCount: function() {
		return this._selectData.getRerollCount();
	},

	forceEnd: function() {
		this._isForceEnd = true;
	},

    getEventCommandName: function() {
		return FotF_SupportConvoSettings.EventCommandName;
	},
	
	changeSelectorMode: function(mode) {
		this._mode = mode;
	},
	
	getConvoList: function(unit) {
		var i, data;
		var count = unit.getSupportDataCount();
		var arr = [];
		
		
		for (i = 0; i < count; i++) {
			data = unit.getSupportData(i);
			
			if ((!data.isGlobalSwitchOn() || !data.isVariableOn()) && data.getUnit().getAliveState() === AliveType.ALIVE) {
				arr.push(data.getUnit());
			}
		}
		
		var list = StructureBuilder.buildDataList();
		list.setDataArray(arr);
		
		return list;
	},
	
	getConvoUnitList: function(dataList) {
		var i;
		var arr = [];
		for (i = 0; i < dataList.getCount(); i++) {
			var unit = dataList.getData(i);
			var convoList = this.getConvoList(unit);
			if (convoList.getCount() > 0) {
				arr.push(unit);
			}
		}
		var list = StructureBuilder.buildDataList();
		list.setDataArray(arr);
		
		return list;
	},
	
	getFilteredUnitList: function(originalData) {
		var i;
		var content = originalData.getOriginalContent();
		var agg = content.getTargetAggregation();
		var count = agg.getObjectCount();
		var list = StructureBuilder.buildDataList();
		var arr = [];
		
		if (agg.getMatchType() === MatchType.MATCHALL) {
			for (i = 0; i < count; i++) {
				var check = agg.getData(i);
				if (check.getObjectType() === ObjectType.UNIT) {
					arr.push(check);
				}
			}
		} else if (agg.getMatchType() === MatchType.MISMATCH || agg.getMatchType() === MatchType.MISMATCHALL) {
			arr = PlayerList.getAliveDefaultList()._arr;
			for (i = 0; i < count; i++) {
				var check = agg.getData(i);
				if (check.getObjectType() === ObjectType.UNIT) {
					arr.splice(i, 1);
				}
			}
		} else {
			arr = PlayerList.getAliveDefaultList()._arr;
		}
		
		list.setDataArray(arr);
		return list;
	},
	
	drawConvo: function() {
		
		var x = LayoutControl.getCenterX(-1, this._convoWindow.getWindowWidth()) + FotF_SupportConvoSettings.WindowOffsetX;
		var y = LayoutControl.getCenterY(-1, this._convoWindow.getWindowHeight()) + FotF_SupportConvoSettings.WindowOffsetY;
		var dx = this._convoWindow.getWindowXPadding();
		var dy = this._convoWindow.getWindowYPadding();
		
		this._convoWindow.drawWindow(x, y);
		//this._messageView.drawMessageView(x + dx, y + dy);
		
		var preText = this._messageView._parsedText;														//Not even god can stop me from mutilating the message analyzer
		var text = this.parseEventString(preText, this._unit1, this._unit2);
		
		if (typeof text === 'string') {
			var font = root.getBaseData().getFontList().getDataFromId(FotF_SupportConvoSettings.FontId);
			var color = FotF_SupportConvoSettings.TextColor;
			var length = TextRenderer.getTextWidth(text, font);
			var width = this._convoWindow.getWindowWidth() - (DefineControl.getWindowXPadding() * 2);
			var height = this._convoWindow.getWindowHeight() - (DefineControl.getWindowYPadding() * 2);
			var range = createRangeObject(x + dx, y + dy, width, height);
			TextRenderer.drawRangeText(range, TextFormat.LEFT, text, length, color, font);
		}
		
		return MoveResult.CONTINUE;
	},
	
	executeConvoEvent: function() {
		var i, j;
		var generator = this._dynamicEvent.acquireEventGenerator();
		var data = this._event;
		var unit1 = this._unit1;
		var unit2 = this._unit2;
		var content = data.getOriginalContent();
		var agg = content.getTargetAggregation();
		var probArr1 = data.custom.itemProb;
		var probArr2 = data.custom.skillProb;
		var count = agg.getObjectCount();
		var itemCount = content.getValue(0);
		var skillCount = content.getValue(2);
		var exp = content.getValue(1);
		var skillDistributionType = content.getValue(3);
		var expDistributionType = content.getValue(4);
		var gold = content.getValue(5);
		var cumProb1 = 0;																		//cum stands for cumulative, what did you think?
		var cumProb2 = 0;
		var cumArr1 = [];
		var cumArr2 = [];
		var itemArr = [];
		var skillArr = [];
		var unitSkillArray = [];
		var refArr1 = SkillControl.getSkillMixArray(this._unit1, BattlerChecker.getRealBattleWeapon(this._unit1), -1, '');
		var refArr2 = SkillControl.getSkillMixArray(this._unit2, BattlerChecker.getRealBattleWeapon(this._unit2), -1, '');

		for (i = 0; i < count; i++) {
			if (agg.getObjectType(i) === ObjectType.WEAPON || agg.getObjectType(i) === ObjectType.ITEM) {
				itemArr.push(agg.getObjectData(i));
			} else if (agg.getObjectType(i) === ObjectType.SKILL) {
				skillArr.push(agg.getObjectData(i));
			}
		}
		
		if (skillDistributionType === 0) {
			for (i = 0; i < skillArr.length; i++) {
				var skill = skillArr[i];
				if (this.isSkillPossessed(skill, refArr1) && this.isSkillPossessed(skill, refArr2)) {
					skillArr.splice(i, 1);
					probArr2.splice(i, 1);
					i--;
				}
			}
		} else if (skillDistributionType === 1) {
			for (i = 0; i < skillArr.length; i++) {
				var skill = skillArr[i];
				if (this.isSkillPossessed(skill, refArr1)) {
					skillArr.splice(i, 1);
					probArr2.splice(i, 1);
					i--;
				}
			}
		} else if (skillDistributionType === 2) {
			for (i = 0; i < skillArr.length; i++) {
				var skill = skillArr[i];
				if (this.isSkillPossessed(skill, refArr2)) {
					skillArr.splice(i, 1);
					probArr2.splice(i, 1);
					i--;
				}
			}
		}
		
		for (i = 0; i < itemArr.length; i++) {
			if (typeof probArr1 !== 'undefined' && probArr1.length === itemArr.length) {
				cumProb1 += probArr1[i];
			} else {
				cumProb1 += 1;
			}
			cumArr1.push(cumProb1);
		}
		
		for (i = 0; i < itemCount; i++) {
			var random = Math.floor((root.getRandomNumber() / 32768 * (cumProb1 + 1)));			//random number between 1 and cumProb
			var index = this.checkCumulativeArray(cumArr1, random);
			this._itemArray.push(itemArr[index]);
		}
		
		for (i = 0; i < skillArr.length; i++) {
			if (typeof probArr2 !== 'undefined' && probArr2.length === skillArr.length) {
				cumProb2 += probArr2[i];
			} else {
				cumProb2 += 1;
			}
			cumArr2.push(cumProb2);
		}
		
		for (i = 0; i < skillCount; i++) {
			
			//Abort if not enough valid skills exist
			if (skillArr.length <= 0) {
				break;
			}
			
			var random = Math.floor((root.getRandomNumber() / 32768 * (cumProb2 + 1)));
			var index = this.checkCumulativeArray(cumArr2, random);
			this._skillArray.push(skillArr[index]);
			
			skillArr.splice(index, 1);															//remove given skill from possible rewards, cause skill doubling is weird
			cumProb2 -= probArr2[index];
			cumArr2.splice(index, 1);
		}
		
		for (i = 0; i < this._itemArray.length; i++) {
			var item = this._itemArray[i]
			this._eventWaitChain.push([ObjectType.ITEM, item, IncreaseType.INCREASE]);
		}
		
		for (i = 0; i < this._skillArray.length; i++) {
			var skill = this._skillArray[i];
			if (skillDistributionType === 0 || skillDistributionType === 1) {
				this._eventWaitChain.push([ObjectType.SKILL, skill, IncreaseType.INCREASE, this._unit1]);
			}
			if (skillDistributionType === 0 || skillDistributionType === 2) {
				this._eventWaitChain.push([ObjectType.SKILL, skill, IncreaseType.INCREASE, this._unit2]);
			}
		}
		
		if (exp > 0) {
			if (expDistributionType === 0 || expDistributionType === 1) {
				this._eventWaitChain.push([ObjectType.UNIT, this._unit1, exp]);
			}
			if (expDistributionType === 0 || expDistributionType === 2) {
				this._eventWaitChain.push([ObjectType.UNIT, this._unit2, exp]);
			}
		}
		
		if (gold > 0) {
				this._eventWaitChain.push([ObjectType.GOLD, IncreaseType.INCREASE, gold]);
		}
		
		
		
		this._isDynamicEvent = true;
	},
	
	checkCumulativeArray: function(arr, treshold) {
		var i;
		for (i = 0; i < arr.length; i++) {
			if (arr[i] >= treshold) {
				return i;
			}
		}
	},
	
	isSkillPossessed: function(skill, arr) {
		var i;
		for (i = 0; i < arr.length; i++) {
			if (skill.getId() === arr[i].skill.getId()) {
				return true;
			}
		}
		return false;
	},
	
	parseEventString: function(string, unit1, unit2) {
		var i;
		var name1 = unit1.getName();
		var name2 = unit2.getName();
		var count = string.length;
		
		for (i = 0; i < count; i++) {
			var c = string.charAt(i);
			if (c === '{') {
				var d = string.charAt(i + 1);
				var e = string.charAt(i + 2);
				var f = string.charAt(i + 3);
				if (d === 'u' && f === '}') {
					if (e === '1') {
						var sub1 = string.substring(0, i);
						var sub2 = string.substring(i + 4, count);
						string = sub1 + name1 + sub2;
						//skip replaced name
						i += name1.length;
					} else if (e === '2') {
						var sub1 = string.substring(0, i);
						var sub2 = string.substring(i + 4, count);
						string = sub1 + name2 + sub2;
						//skip replaced name
						i += name1.length;
					}
				}
			}
		}
		return string;
	}
	
/*		//obsolete//

	preParseString: function(string) {
		var i;
		var count = string.length;
		
		for (i = 0; i < count; i++) {
			var c = string.charAt(i);
			if (c === '{') {
				var d = string.charAt(i + 1);
				var e = string.charAt(i + 2);
				if (d === '/' && e === '}') {
					var sub1 = string.substring(0, i);
					var sub2 = string.substring(i + 3, count);
					string = sub1 + "\\" + sub2;					//two backslashes because one needs to be escaped, coding is weird sometimes
					//account for 2 lost characters
					i -= 2;
				}
			}
		}
		return string;
	}
*/	
});


SelectorData.ConvoUnit = defineObject(BaseSelectorData, {
    getSelectorDataName: function() {
        return "convounit";
    },

    getDefaultDataList: function() {
        return root.getBaseData().getPlayerList();
    },

    getSessionDataList: function() {
        return PlayerList.getSortieDefaultList();
    },

    getObjectType: function() {
        return ObjectType.UNIT;
    },

    _getWindowManager: function() {
        return SelectorEventUnitWindowManager;
    }
});

SelectorData.ConvoTarget = defineObject(BaseSelectorData, {
    getSelectorDataName: function() {
        return "targetunit";
    },

    getDefaultDataList: function() {
        return root.getBaseData().getPlayerList();
    },

    getSessionDataList: function() {
        return PlayerList.getSortieDefaultList();
    },

    getObjectType: function() {
        return ObjectType.UNIT;
    },

    _getWindowManager: function() {
        return SelectorEventUnitWindowManager;
    }
});

SelectorData.ConvoEventData = defineObject(BaseSelectorData, {
    getSelectorDataName: function() {
        return "convodata";
    },

    getDefaultDataList: function() {
        return root.getBaseData().getOriginalDataList(this._getOriginalDataIndex());
    },

    _getOriginalDataIndex: function() {
        return FotF_SupportConvoSettings.OriginalDataEvent;
    },

    _setAdditionalData: function(unit, dataList) {
        this._windowManager = createWindowObject(FotF_SelectorEventConvoWindowManager, this);
        this._windowManager.setData(unit, dataList);
    }
});

var FotF_ConvoWindow = defineObject(BaseWindow, {
	
	_activityText: null,
	_messageView: null,
	_messageViewParam: null,
	
	setActivityText: function(text) {
		this._activityText = text;
	},
	
	prepareMessageView: function() {
		this._messageViewParam = StructureBuilder.buildMessageViewParam();		
		this._messageViewParam.messageLayout = root.getDefaultMessageLayout(MessageLayout.STILL);
		this._messageViewParam.text = this._activityText;
		
		if (this._messageViewParam.text === null) {
			this._messageViewParam.text = '';
		}
		
		this._messageView = createObject(FotF_ConvoMessageView);
		this._messageView.setupMessageView(this._messageViewParam, this.getWindowTextUI());
	},
	
	drawWindowContent: function(x, y) {
		/*
		var textUI = this.getWindowTextUI();
		
		if (textUI === null || this._activityText === '') {
			return;
		}
		
		var font = textUI.getFont();
		var dx = this.getWindowXPadding();
		var dy = this.getWindowYPadding();
		var width = this.getWindowWidth() - (DefineControl.getWindowXPadding() * 2);
		var height = this.getWindowHeight() - (DefineControl.getWindowYPadding() * 2);
		//var length = TextRenderer.getTextWidth(this._activityText, font);
		var color = 0xFFFFFF;
		var range = createRangeObject(x + dx, y + dy, width, height);
		//TextRenderer.drawRangeText(range, TextFormat.LEFT, this._activityText, length, color, font);
		//this._messageView.drawMessageView(x + dx, y + dy);
		*/
	},
	
	getWindowTitleTextUI: function() {
		return root.queryTextUI("infowindow_title");
	},
	
	getWindowTitleText: function() {
		return FotF_SupportConvoSettings.ConvoWindowTitle;
	},
	
	getWindowWidth: function() {
		return FotF_SupportConvoSettings.WindowWidth;
	},
	
	getWindowHeight: function() {
		return FotF_SupportConvoSettings.WindowHeight;
	}
});

//I HATE THE MESSAGE ANALYZER I HATE THE MESSAGE ANALYZER I HATE THE MESSAGE ANALYZER 
//I HATE THE MESSAGE ANALYZER I HATE THE MESSAGE ANALYZER I HATE THE MESSAGE ANALYZER 
//I HATE THE MESSAGE ANALYZER I HATE THE MESSAGE ANALYZER I HATE THE MESSAGE ANALYZER 
var FotF_ConvoMessageView = defineObject(BaseMessageView, {

	_messageLayout: null,
	_activePos: MessagePos.NONE,
	_isNameDisplayable: false,
	_isWindowDisplayable: false,
	_faceId: 0,
	_illustId: 0,
	_name: null,
	_faceHandle: null,
	_illustImage: null,
	_messageAnalyzer: null,
	_x: 0,
	_y: 0,
	_parsedText: null,
/*	
	setupMessageView: function(messageViewParam, textui) {
		this._messageLayout = messageViewParam.messageLayout;
		this._x = messageViewParam.x;
		this._y = messageViewParam.y;
		this._messageAnalyzer = this.createMessageAnalyzer(messageViewParam);
		var messageAnalyzerParam = StructureBuilder.buildMessageAnalyzerParam();
		
		messageAnalyzerParam.color = textui.getColor();
		messageAnalyzerParam.font = textui.getFont();
		messageAnalyzerParam.messageSpeedType = SpeedType.DIRECT;
		this._messageAnalyzer.setMessageAnalyzerText(messageViewParam.text);
		this._messageAnalyzer.setMessageAnalyzerParam(messageAnalyzerParam);
		
	},
*/	
	setupMessageView: function(messageViewParam) {
		this._messageLayout = messageViewParam.messageLayout;
		this._activePos = messageViewParam.pos;
		this._isNameDisplayable = messageViewParam.isNameDisplayable;
		this._isWindowDisplayable = messageViewParam.isWindowDisplayable;
		var messageAnalyzerParam = StructureBuilder.buildMessageAnalyzerParam();
		messageAnalyzerParam.font = root.getBaseData().getFontList().getDataFromId(FotF_SupportConvoSettings.FontId);
		messageAnalyzerParam.color = FotF_SupportConvoSettings.TextColor;
		
		this._x = messageViewParam.x;
		this._y = messageViewParam.y;
		
		this._messageAnalyzer = createObject(MessageAnalyzer);
		this._messageAnalyzer.setMessageAnalyzerParam(messageAnalyzerParam);
		this._messageAnalyzer.setMessageAnalyzerText(messageViewParam.text);
		this._parsedText = this._messageAnalyzer.getCoreAnalyzer()._totalText;
	},
	
	moveMessageView: function() {
		return this._messageAnalyzer.moveMessageAnalyzer();
	},
	
	drawMessageView: function(x, y) {
		var xText = x;
		var yText = y;
		var xCursor = x + this._messageLayout.getCursorX();
		var yCursor = y + this._messageLayout.getCursorY();

		this._messageAnalyzer.drawMessageAnalyzer(xText, yText, xCursor, yCursor, this._messageLayout.getPageCursorUI());
		//this._messageAnalyzer.getCoreAnalyzer().drawCoreAnalyzer(xText, yText);
	},
	
	getTextWindowWidth: function() {
		return FotF_SupportConvoSettings.WindowWidth;
	},
	
	getTextWindowHeight: function() {
		return FotF_SupportConvoSettings.WindowHeight;
	},
	
	drawMessageWindow: function(xWindow, yWindow) {
	},
	
	drawFace: function(xDest, yDest, isActive) {
	},
	
	drawName: function(x, y) {
	},
	
	drawCharIllust: function(isActive) {
	},
	
	_setupName: function(messageViewParam) {
	},
	
	_setupFaceHandle: function(messageViewParam) {
	},
	
	_setupIllustImage: function(messageViewParam) {
	},
	
	_setupFaceHandle: function(messageViewParam) {
	},
	
	getMessagePos: function() {
		var pos = createPos(this._x, this._y);
		
		return pos;
	},
	
	_createMessageAnalyzerParam: function(messageViewParam) {
		var textui = this._messageLayout.getWindowTextUI();
		var messageAnalyzerParam = StructureBuilder.buildMessageAnalyzerParam();
		
		messageAnalyzerParam.color = FotF_SupportConvoSettings.TextColor;
		messageAnalyzerParam.font = font = root.getBaseData().getFontList().getDataFromId(FotF_SupportConvoSettings.FontId);
		messageAnalyzerParam.voiceSoundHandle = this._messageLayout.getVoiceSoundHandle();
		messageAnalyzerParam.pageSoundHandle = this._messageLayout.getPageSoundHandle();
		messageAnalyzerParam.messageSpeedType = this.getMessageSpeedType();
		
		return messageAnalyzerParam;
	}

});

/*
var FotF_ConvoMessageView = defineObject(BaseMessageView,
{
	_messageLayout: null,
	_activePos: MessagePos.NONE,
	_isNameDisplayable: false,
	_isWindowDisplayable: false,
	_faceId: 0,
	_illustId: 0,
	_name: null,
	_faceHandle: null,
	_illustImage: null,
	_messageAnalyzer: null,
	_x: 0,
	_y: 0,
	_containerArray: null,
	
	setupMessageView: function(messageViewParam, textui) {
		this._messageLayout = messageViewParam.messageLayout;
		this._x = messageViewParam.x;
		this._y = messageViewParam.y;
		this._messageAnalyzer = this.createMessageAnalyzer(messageViewParam);
		var messageAnalyzerParam = StructureBuilder.buildMessageAnalyzerParam();
		
		messageAnalyzerParam.color = textui.getColor();
		messageAnalyzerParam.font = textui.getFont();
		messageAnalyzerParam.messageSpeedType = SpeedType.DIRECT;
		this._messageAnalyzer.setMessageAnalyzerText(messageViewParam.text);
		this._messageAnalyzer.setMessageAnalyzerParam(messageAnalyzerParam);
		
	},
	
	moveMessageView: function() {
		return this._messageAnalyzer.moveMessageAnalyzer();
	},
	
	drawMessageView: function(x, y) {
		var xText = x + this._messageLayout.getTextX();
		var yText = y + this._messageLayout.getTextY();
		var xCursor = x + this._messageLayout.getCursorX();
		var yCursor = y + this._messageLayout.getCursorY();

		this._messageAnalyzer.drawMessageAnalyzer(xText, yText, xCursor, yCursor, this._messageLayout.getPageCursorUI());
	},
	
	drawMessageWindow: function(xWindow, yWindow) {
	},
	
	drawFace: function(xDest, yDest, isActive) {
	},
	
	drawName: function(x, y) {
	},
	
	drawCharIllust: function(isActive) {
	},
	
	_setupName: function(messageViewParam) {
		var name = '';
		
		if (messageViewParam.unit !== null) {
			name = messageViewParam.unit.getName();
		}
		else if (messageViewParam.npc !== null) {
			name = messageViewParam.npc.getName();
		}
		
		this._name = name;
	},
	
	_setupFaceHandle: function(messageViewParam) {
	},
	
	_setupIllustImage: function(messageViewParam) {
	},
	
	_setupFaceHandle: function(messageViewParam) {
	},
	
	getMessagePos: function() {
		var pos = createPos(this._x, this._y);
		
		return pos;
	},
	
	_createMessageAnalyzerParam: function(messageViewParam) {
		var textui = this._messageLayout.getWindowTextUI();
		var messageAnalyzerParam = StructureBuilder.buildMessageAnalyzerParam();
		
		messageAnalyzerParam.color = textui.getColor();
		messageAnalyzerParam.font = textui.getFont();
		messageAnalyzerParam.voiceSoundHandle = this._messageLayout.getVoiceSoundHandle();
		messageAnalyzerParam.pageSoundHandle = this._messageLayout.getPageSoundHandle();
		messageAnalyzerParam.messageSpeedType = this.getMessageSpeedType();
		
		return messageAnalyzerParam;
	}
});
*/
This is basically MarkyJoe's selector event command but with my modifications.
All credit for the basis of my work on this goes to MarkyJoe.
For general instructions on how his plugin (and this one to some extent) works, please read the readme.html
var FotF_SelectorEventConvoWindowManager = defineObject(BaseSelectEventWindowManager, {
	 _getMainWindow: function() {
        return SelectorEventConvoWindow;
    }
});

var SelectorEventConvoWindow = defineObject(BaseSelectEventWindow, {
    _getScrollbarObject: function() {
        return SelectorEventOriginalDataScrollbar;
    },

    getWindowTitleText: function() {
		return FotF_SupportConvoSettings.EventWindowTitle;
	}
});

var SelectorEventConvoScrollbar = defineObject(BaseSelectEventScrollbar, {
});
Before deleting save files from this sample project, be aware they are used to store progress between
the game terminating itself and you re-opening it during the practical exercises.

Each exercise has it's own save slot (Slot 1 for exercise 1, slot 2 for exercise 2, ...) and the previous
slot will be deleted once a new one is used. So at any time, there should be only one save file present
in this folder.

If you want to restart the exercises, feel free to delete the save files in here. The process is repeat-
able, so you will be taken back to the first opening event of the exercise map.
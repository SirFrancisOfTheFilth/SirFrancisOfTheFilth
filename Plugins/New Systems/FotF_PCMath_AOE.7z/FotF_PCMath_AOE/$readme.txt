This plugin is built off the version https://srpg-studio.fandom.com/wiki/Splash_Damage_Plugin of O-To's AoE plugin.
Up to date translation of O-To's plugin is available: https://github.com/Anarch16Sync/SRPG-Studio-Translated-Plugins/blob/O-to_Plugins/AoE%20Pack/
Yes, this is a modification of a modification. I felt it necessary to add some features.

Original plugin: O-To
Modified version: PCMath
Further Modified: Francis of the Filth

//// How to set up an AOE item ////

Create an item with type "Custom" and set the custom keyword to "AOE".
Then give the item a custom parameter such as:

{
	aoe: {
		weapon: 4,
		selectionRange: {
			rangeType: "adjacent"
		},
		effectRange: {
			rangeType: "line3"
		}
	}
}


//// About the weapon ////

This ID is required to link the AOE item to a weapon. Information like damage,
hit and optional states are pulled from the reference weapon.


//// About selection and effect range ////

Selection range is chosen by the name of a range object in aoe-dictionary.js.
The same applies to effect range. They vary in such a way, that selection range
is the shape of tiles the attack can be placed in, while effect range is the
"size" of the AOE.

For all possible ranges (or to add some yourself), look at the dictionary file.


//// About the state ID ////

This parameter is optional and lets the AOE item inflict a state


//// Showing AOE stats in the item info window ////

This plugin relies heavily on my Infowindow Overhaul plugin to display it's
stats. Please also download and configure the Infowindow Overhaul if you want
to use this feature.


//// Miscellaneous ////

Please note that skills are not passed from the override weapon.
The z_addon folder needs to be after the aoe scripts in reading order.

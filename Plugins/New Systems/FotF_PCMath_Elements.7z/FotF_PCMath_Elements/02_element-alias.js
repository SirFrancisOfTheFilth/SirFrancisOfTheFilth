(function () {
    var alias0 = DamageCalculator.calculateDamage;
    DamageCalculator.calculateDamage = function (active, passive, weapon, isCritical, activeTotalStatus, passiveTotalStatus, trueHitValue) {
        var damage = alias0.call(this, active, passive, weapon, isCritical, activeTotalStatus, passiveTotalStatus, trueHitValue);
        if (!weapon.custom.element) {
            return damage;
        }
        var rate = ElementControl.getRate(weapon.custom.element, active, passive);

        damage = Math.floor(damage * rate);
        return damage;
    };

    //Modify state damage with multiplicative param bonus and element rate
    var FotF_AddElementState = StateControl.getHpValue;
    StateControl.getHpValue = function (unit) {
        var value = FotF_AddElementState.call(this, unit);
        var i, state, bonus;
        var list = unit.getTurnStateList();
        var count = list.getCount();

        for (i = 0; i < count; i++) {
            state = list.getData(i).getState();
            bonus = 0;

            if (typeof ElementControl === 'object') {
                bonus += state.getAutoRecoveryValue();

                if (typeof FotF_ParamFactorControl === 'object') {
                    bonus += FotF_ParamFactorControl.calculateRegenBonus(unit, state);
                }

                var rate = ElementControl.getRate(state.custom.element, null, unit);

                //vanilla and param factor values are applied elsewhere, so subtract them again
                bonus = Math.floor(bonus * rate) - bonus;
            }

            value += bonus;
        }

        return value;
    };
})();

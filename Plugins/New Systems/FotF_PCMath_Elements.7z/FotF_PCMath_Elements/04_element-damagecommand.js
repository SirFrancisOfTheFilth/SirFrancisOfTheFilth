var FotF_ActiveDamageElement = null;

(function () {
    var FotF_AdjustCommandDamageElement = DamageHitEventCommand._createDamageData;
    DamageHitEventCommand._createDamageData = function () {
        var savedHp = root.getEventCommandObject().getTargetUnit().getHp();
        var damageData = FotF_AdjustCommandDamageElement.call(this);
        var element = FotF_ActiveDamageElement;
        if (typeof element === 'string') {
            damageData.targetUnit.setHp(savedHp);
            var rate = ElementControl.getRate(element, damageData.launchUnit, damageData.targetUnit);

            var i;
            var skills = SkillControl.getDirectSkillArray(damageData.targetUnit, -1, 'NegateElement');

            for (i = 0; i < skills.length; i++) {
                var skill = skills[i].skill;
                root.log(skill.getName());
                if (skill !== null && skill.custom.elementNegate && skill.custom.elementNegate[element] === true && skill.getTargetAggregation().isCondition(damageData.targetUnit) && Probability.getInvocationProbabilityFromSkill(damageData.targetUnit, skill)) {
                    rate = 0;
                }
            }

            damageData.damage = Math.floor(damageData.damage * rate);
            damageData.curHp = this._getHp(damageData);
        }
        ElementControl.resetActiveElement();

        return damageData;
    };
})();

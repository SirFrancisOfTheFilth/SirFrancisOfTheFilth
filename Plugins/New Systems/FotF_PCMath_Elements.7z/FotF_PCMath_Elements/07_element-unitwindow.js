(function() {
	var alias11 = UnitMenuScreen._configureBottomWindows;
	UnitMenuScreen._configureBottomWindows = function(groupArray) {
		alias11.call(this, groupArray);
		groupArray.appendWindowObject(ElementWindow, this);
	}
})();

var ElementWindow = defineObject(BaseMenuBottomWindow, {
	_elementScrollbar: null,
	_unit: null,
	setUnitMenuData: function() {
		this._elementScrollbar = createScrollbarObject(ElementScrollbar, this);
	},
	changeUnitMenuTarget: function(unit) {
		this._unit = unit;
		this._elementScrollbar.prepareStatus();
		this._elementScrollbar.setStatusFromUnit(unit);
	},
    
	drawWindowContent: function(x, y) {
 		var textui = root.queryTextUI('infowindow_title');
		var color = textui.getColor();
		var font = textui.getFont();
		TextRenderer.drawText(x, y, "Element Rates", 10, color, font);
		this._drawElements(x, y + 30);
	},

	_drawElements: function(x, y) {
		this._elementScrollbar.drawScrollbar(x, y);
	}

});


//The scrollbar that draws each weapon type and their rank
var ElementScrollbar = defineObject(UnitStatusScrollbar, {
	_elementDict: {},
	_statusArray: [],

	prepareStatus: function(){
		for(element in ElementControl.StandardElement) {
			this._elementDict[element] = 1.0
		}
	},

	setStatusFromUnit: function(unit) {
		for(element in this._elementDict) {
			this._elementDict[element] *= ElementControl.getRate(element, null, unit);
		}
		this._fillStatusEntry();
		this.setScrollFormation(this.getDefaultCol(), this.getDefaultRow());
		this.setObjectArray(this._statusArray);
	},

	drawScrollContent: function(x, y, object, isSelect, index) {
		var statusEntry = object;
		var n = statusEntry.param;
		var text = ElementControl.getElementString(statusEntry.type);
		var textui = this.getParentTextUI();
		var font = textui.getFont();
		var length = this._getTextLength();	
		statusEntry.textui = textui;
		if (!statusEntry.isRenderable) {
			return ;
		}
		TextRenderer.drawKeywordText(x, y, text, length, ColorValue.KEYWORD, font);
		x += this._getNumberSpace();
		if (n < 0) {
			n = 0;
		}
		NumberRenderer.drawNumber(x, y, n);
		if (statusEntry.bonus !== 0) {
			this._drawBonus(x, y, statusEntry);
		}
	},

	_fillStatusEntry: function() {
		var index = 0;
		for(element in this._elementDict) {
			this._statusArray[index] = this._createStatusEntry(element, this._elementDict[element], index);
			index++;
		}
	},

	_createStatusEntry: function(elementName, elementRate, index) {
		var statusEntry = StructureBuilder.buildStatusEntry();
		statusEntry.type = elementName;
		statusEntry.param = Math.floor(elementRate*100);
		statusEntry.bonus = 0;
		statusEntry.index = index;
		statusEntry.isRenderable = true;
		statusEntry.visible = true;
		return statusEntry;
	}
});
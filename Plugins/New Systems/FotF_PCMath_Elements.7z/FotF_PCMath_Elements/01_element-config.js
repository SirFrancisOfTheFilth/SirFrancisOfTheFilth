var FotF_ElementRendererSettings = {
    //Material
    materialFolder: 'FotF_DamageTypes',
    iconPrefix: 'DamageType_',
    iconFileType: '.png',

    //Sizing
    iconWidth: 16,
    iconHeight: 16,

    //Strings
    elementString1: 'Deals',
    elementString2: 'damage',
    elementBoost: 'Damage Boost',
    elementResist: 'Damage Modifier',
    elementNegate: 'Negates Damage',

    //Offsets
    infoWindowSpacingX: 160,
    iconOffsetY: 2
};

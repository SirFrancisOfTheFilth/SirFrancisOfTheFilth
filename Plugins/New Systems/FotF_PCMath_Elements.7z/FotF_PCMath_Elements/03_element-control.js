var ElementControl = {
    StandardElement: {
        slashing: 1,
        piercing: 1,
        blunt: 1,
        chemical: 1,
        explosion: 1,
        fire: 1,
        frost: 1,
        water: 1,
        lightning: 1,
        light: 1,
        dark: 1,
        mental: 1
    },

    getElementString: function (element) {
        return element.charAt(0).toUpperCase() + element.slice(1);
    },

    getRate: function (element, active, passive) {
        /*
		Compute the element rate against unit
		Parameters:
			element: element (string)
			active: attacking unit (unit)
			passive: defending unit (unit)
		Returns:
			rate: damage coefficient (float)
		*/
        var rate = 1.0;
        if (!passive) {
            return rate;
        }
        var methodArray = this.getRateMethodArray();
        for (var i = 0, count = methodArray.length; i < count; i++) {
            rate *= methodArray[i](element, active, passive);
        }
        return rate;
    },

    getObjectRate: function (element, object) {
        if (object.elementRate && object.elementRate[element] != null) {
            return object.elementRate[element] / 100;
        }
        return 1.0;
    },

    getAttackRate: function (element, object) {
        if (object.elementBoost && object.elementBoost[element] != null) {
            return object.elementBoost[element] / 100;
        }
        return 1.0;
    },

    getDefendRate: function (element, object) {
        if (object.elementResist && object.elementResist[element] != null) {
            return object.elementResist[element] / 100;
        }
        return 1.0;
    },

    _getActualClassDefendRate: function (element, cls) {
        var rate = 1.0;
        rate *= this.getObjectRate(element, cls.custom);

        return rate;
    },

    _getActualDefendClassRate: function (element, active, passive) {
        return ElementControl._getActualClassDefendRate(element, passive.getClass());
    },

    _getClassDefendRate: function (element, cls) {
        var rate = 1.0;
        var refList = cls.getRaceReferenceList();
        var count = refList.getTypeCount();
        var data;
        for (var i = 0; i < count; i++) {
            data = refList.getTypeData(i);
            rate *= this.getObjectRate(element, data.custom);
        }
        return rate;
    },

    _getDefendClassRate: function (element, active, passive) {
        return ElementControl._getClassDefendRate(element, passive.getClass());
    },

    _getSkillRate: function (element, active, passive) {
        var i;
        var rate = 1.0;
        var activeSkills = SkillControl.getDirectSkillArray(active, -1, '');
        var passiveSkills = SkillControl.getDirectSkillArray(passive, -1, '');

        for (i = 0; i < activeSkills.length; i++) {
            var skill = activeSkills[i].skill;
            rate *= ElementControl.getAttackRate(element, skill.custom);
        }

        for (i = 0; i < passiveSkills.length; i++) {
            var skill = passiveSkills[i].skill;
            rate *= ElementControl.getDefendRate(element, skill.custom);
        }

        return rate;
    },

    _getStateRate: function (element, active, passive) {
        var i;
        var rate = 1.0;

        if (active !== null) {
            var activeStates = active.getTurnStateList();
        } else {
            var activeStates = StructureBuilder.buildDataList();
            activeStates.setDataArray([]);
        }

        if (passive !== null) {
            var passiveStates = passive.getTurnStateList();
        } else {
            var passiveStates = StructureBuilder.buildDataList();
            passiveStates.setDataArray([]);
        }

        for (i = 0; i < activeStates.getCount(); i++) {
            var state = activeStates.getData(i).getState();
            rate *= ElementControl.getAttackRate(element, state.custom);
        }

        for (i = 0; i < passiveStates.getCount(); i++) {
            var state = passiveStates.getData(i).getState();
            rate *= ElementControl.getDefendRate(element, state.custom);
        }

        return rate;
    },

    _getTerrainRate: function (element, active, passive) {
        var rate = 1.0;

        if (active !== null) {
            var terrain = PosChecker.getTerrainFromPos(active.getMapX(), active.getMapY());
            if (terrain !== null) {
                rate *= ElementControl.getAttackRate(element, terrain.custom);
            }
        }

        if (passive !== null) {
            var terrain = PosChecker.getTerrainFromPos(passive.getMapX(), passive.getMapY());
            if (terrain !== null) {
                rate *= ElementControl.getDefendRate(element, terrain.custom);
            }
        }

        return rate;
    },

    getRateMethodArray: function () {
        methodArray = [];
        methodArray.push(ElementControl._getActualDefendClassRate);
        methodArray.push(ElementControl._getDefendClassRate);
        methodArray.push(ElementControl._getSkillRate); //Added skills to boost/resist elemental damage
        methodArray.push(ElementControl._getStateRate); //Aded states to boost/resist elemental damage
        methodArray.push(ElementControl._getTerrainRate); //Aded terrain to boost/resist elemental damage
        return methodArray;
    },

    setActiveElement: function (element) {
        FotF_ActiveDamageElement = element;
    },

    resetActiveElement: function () {
        FotF_ActiveDamageElement = null;
    }
};

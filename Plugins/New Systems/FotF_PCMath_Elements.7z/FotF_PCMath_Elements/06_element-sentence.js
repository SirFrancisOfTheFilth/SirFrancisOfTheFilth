//To draw elemental boosts/resistances to skill/state info
var FotF_ElementRenderer = {
    drawElement: function (x, y, obj) {
        var CFG = FotF_ElementRendererSettings;
        var renderer = FotF_CusparaRenderer;

        var text1 = CFG.elementString1;
        var text2 = ElementControl.getElementString(obj.custom.element);
        var text3 = CFG.elementString2;
        var icon = root.getMaterialManager().createImage(CFG.materialFolder, CFG.iconPrefix + text2 + CFG.iconFileType);

        x += renderer.drawText(x, y, text1);
        x += renderer.drawIcon(x, y, icon);
        x += renderer.drawName(x, y, text2);
        x += renderer.drawText(x, y, text3);
    },

    drawFactorBoost: function (x, y, obj) {
        var cfg = FotF_CusparaRenderSettings;
        var CFG = FotF_ElementRendererSettings;
        var renderer = FotF_CusparaRenderer;

        x += renderer.drawText(x, y, CFG.elementBoost);
        bonusX = x;

        for (element in obj.custom.elementBoost) {
            x = bonusX;
            var name = ElementControl.getElementString(element);
            var n = obj.custom.elementBoost[element] - 100;

            x += renderer.drawName(x, y, name);
            x += renderer.drawSign(x, y, n > 0 ? '+' : '-');

            if (n < 0) {
                n *= -1;
            }

            x += renderer.drawNumber(x, y, n);
            renderer.drawSign(x, y, '%');
            y += cfg.lineSpacingY;
        }
    },

    drawFactorResist: function (x, y, obj) {
        var cfg = FotF_CusparaRenderSettings;
        var CFG = FotF_ElementRendererSettings;
        var renderer = FotF_CusparaRenderer;

        x += renderer.drawText(x, y, CFG.elementResist);
        bonusX = x;

        for (element in obj.custom.elementResist) {
            x = bonusX;
            var name = ElementControl.getElementString(element);
            var n = obj.custom.elementResist[element] - 100;

            x += renderer.drawName(x, y, name);
            x += renderer.drawSign(x, y, n > 0 ? '+' : '-');

            if (n < 0) {
                n *= -1;
            }

            x += renderer.drawNumber(x, y, n);
            renderer.drawSign(x, y, '%');
            y += cfg.lineSpacingY;
        }
    },

    drawElementNegate: function (x, y, obj) {
        var cfg = FotF_CusparaRenderSettings;
        var CFG = FotF_ElementRendererSettings;
        var renderer = FotF_CusparaRenderer;

        x += renderer.drawText(x, y, CFG.elementNegate);
        bonusX = x;

        for (element in obj.custom.elementNegate) {
            x = bonusX;
            var name = ElementControl.getElementString(element);

            renderer.drawName(x, y, name);
            y += cfg.lineSpacingY;
        }
    },

    getSpacingBoost: function (obj) {
        var count = 0;

        if (!obj.custom.elementBoost) {
            return count;
        }

        for (element in obj.custom.elementBoost) {
            if (obj.custom.elementBoost.hasOwnProperty(element)) {
                count++;
            }
        }

        return count;
    },

    getSpacingResist: function (obj) {
        var count = 0;

        if (!obj.custom.elementResist) {
            return count;
        }

        for (element in obj.custom.elementResist) {
            if (obj.custom.elementResist.hasOwnProperty(element)) {
                count++;
            }
        }

        return count;
    },

    getSpacingNegate: function (obj) {
        var count = 0;

        if (!obj.custom.elementNegate) {
            return count;
        }

        for (element in obj.custom.elementNegate) {
            if (obj.custom.elementNegate.hasOwnProperty(element)) {
                count++;
            }
        }

        return count;
    }
};

/*-------------------------------------------------------------
                        ITEM SENTENCE
I rewrote ALL item sentences to use the new drawing methods.
Most still use the old keywords from the string table, but have
been compressed down to one line instead of multiple, as this
plugin is intended to expand the info windows horizontally by
quite a bit. I also combined all combat stats into a single
item sentence that also takes up only a single line.
-------------------------------------------------------------*/

ItemSentence.Cuspara = defineObject(BaseItemSentence, {
    drawItemSentence: function (x, y, item) {
        var cfg = FotF_CusparaRenderSettings;
        var custom = item.custom;
        var isWeapon = item.isWeapon();
        var interval = cfg.lineSpacingY;

        for (string in custom) {
            if (isWeapon) {
                var type = ObjectType.WEAPON;
            } else {
                var type = ObjectType.ITEM;
            }

            var obj = FotF_CusparaRenderer.checkObject(item, string, type);

            if (typeof obj === 'undefined') {
                continue;
            }

            FotF_CusparaRenderer.drawContent(x, y, obj, item);
            y += interval * FotF_CusparaRenderer.getCustomSpacing(obj, item);
        }

        if (cfg.drawDescriptionInInfoWindows) {
            if (typeof this._itemInfoWindow._description !== 'string') {
                var font = root.getBaseData().getFontList().getDataFromId(cfg.descriptionFontId);
                this._itemInfoWindow._description = this._skill.getDescription();
                if (TextRenderer.getTextWidth(this._itemInfoWindow._description, font) > FotF_CusparaRenderer.getMaxDescriptionWidth(type)) {
                    var textLineArray = FotF_TextControlV2.convertTextToLineArray(this._itemInfoWindow._description, font, FotF_CusparaRenderer.getMaxDescriptionWidth(type));
                    this._itemInfoWindow._description = FotF_TextControlV2.convertLineArrayToLineBreakText(textLineArray);
                }
            }
            FotF_CusparaRenderer.drawDescription(x, y, this._itemInfoWindow._description);
        }
    },

    getItemSentenceCount: function (item) {
        var type = item.isWeapon() ? ObjectType.WEAPON : ObjectType.ITEM;
        return FotF_CusparaRenderer.getSentenceCount(item, type);
    }
});

ItemSentence.Title = defineObject(BaseItemSentence, {
    drawItemSentence: function (x, y, item) {
        var cfg = FotF_CusparaRenderSettings;
        var renderer = FotF_CusparaRenderer;
        var handle = item.getIconResourceHandle();

        if (handle !== null) {
            GraphicsRenderer.drawImage(x, y, handle, GraphicsType.ICON);
            x += GraphicsFormat.ICON_WIDTH + cfg.bigIconSpacingX;
        }

        x += renderer.drawTitle(x, y + cfg.titleOffsetY, item.getName());
    },

    getItemSentenceCount: function (item) {
        return FotF_CusparaRenderer.getTitleHeight(1);
    }
});

ItemSentence.CombatStats = defineObject(BaseItemSentence, {
    drawItemSentence: function (x, y, item) {
        var text;
        var renderer = FotF_CusparaRenderer;

        text = root.queryCommand('attack_capacity');
        x += renderer.drawText(x, y, text);
        x += renderer.drawNumber(x, y, item.getPow(), item, null);

        x += this._getMiddleSpace();

        text = root.queryCommand('hit_capacity');
        x += renderer.drawText(x, y, text);
        x += renderer.drawNumber(x, y, item.getHit(), null, null);

        x += this._getMiddleSpace();

        text = root.queryCommand('critical_capacity');
        x += renderer.drawText(x, y, text);
        x += renderer.drawNumber(x, y, item.getCritical(), null, null);

        x += this._getMiddleSpace();

        text = root.queryCommand('range_capacity');
        var start = item.getStartRange();
        var end = item.getEndRange();

        x += renderer.drawText(x, y, text);

        if (start === end) {
            x += renderer.drawNumber(x, y, start, null, null);
        } else {
            x += renderer.drawNumber(x, y, start, null, null);
            x += renderer.drawSign(x, y, '-');
            x += renderer.drawNumber(x, y, end, null, null);
        }

        x += this._getMiddleSpace();

        if (this._isWeaponLevelDisplayable(item)) {
            text = root.queryCommand('wlv_param');
            x += renderer.drawText(x, y, text);
            x += renderer.drawNumber(x, y, item.getWeaponLevel(), null, null);

            x += this._getMiddleSpace();
        }

        if (this._isWeightDisplayable(item)) {
            text = root.queryCommand('weight_capacity');
            x += renderer.drawText(x, y, text);
            x += renderer.drawNumber(x, y, item.getWeight(), null, null);
        }
    },

    _isWeaponLevelDisplayable: function (item) {
        if (!item.isWeapon() || FotF_CusparaRenderSettings.disableWlvInItemInfo) {
            return false;
        }

        return DataConfig.isWeaponLevelDisplayable();
    },

    _isWeightDisplayable: function (item) {
        // Don't display at the time when the item weighs 0.
        if (!item.isWeapon() && item.getWeight() === 0) {
            return false;
        }

        return DataConfig.isItemWeightDisplayable();
    },

    getItemSentenceCount: function (item) {
        return 1;
    }
});

ItemSentence.AdditionState = defineObject(BaseItemSentence, {
    drawItemSentence: function (x, y, item) {
        var i, text, stateInvocation;
        var cfg = FotF_CusparaRenderSettings;
        var renderer = FotF_CusparaRenderer;

        if (this.getItemSentenceCount(item) === 0) {
            return;
        }

        stateInvocation = item.getStateInvocation();

        text = StringTable.State_Addition;
        x += renderer.drawText(x, y, text);
        x += cfg.itemStatSpacingX;

        if (item.getStateInvocation().getState() !== null) {
            renderer.drawName(x, y, item.getStateInvocation().getState().getName());
            y += ItemInfoRenderer.getSpaceY();
        }

        var arr = item.custom.MultiStateList;
        if (typeof arr === 'object') {
            for (i = 0; i < arr.length; i++) {
                var state = root.getBaseData().getStateList().getDataFromId(arr[i]);
                if (state !== null) {
                    renderer.drawInvocation(x, y, state, item.getStateInvocation().getInvocationValue(), item.getStateInvocation().getInvocationType());
                    y += ItemInfoRenderer.getSpaceY();
                }
            }
        }
    },

    getItemSentenceCount: function (item) {
        var count = 0;

        if (item.getStateInvocation().getState() !== null) {
            count++;
        }

        if (typeof item.custom.MultiStateList === 'object') {
            count += item.custom.MultiStateList.length;
        }

        return count;
    }
});

ItemSentence.WeaponOption = defineObject(BaseItemSentence, {
    drawItemSentence: function (x, y, item) {
        var text;
        var renderer = FotF_CusparaRenderer;
        var attackCount = item.getAttackCount();

        if (attackCount > 1) {
            x += renderer.drawNumber(x, y, attackCount, null, null);
            x += renderer.drawText(x, y, StringTable.ItemWord_MultiAttack);
            x += this._getMiddleSpace();
        }

        text = this._getWeaponOptionText(item);
        if (text !== '') {
            renderer.drawText(x, y, text);
        }
    },

    getItemSentenceCount: function (item) {
        return item.getAttackCount() > 1 || item.getWeaponOption() !== WeaponOption.NONE ? 1 : 0;
    },

    _getWeaponOptionText: function (item) {
        var text;
        var option = item.getWeaponOption();

        if (option === WeaponOption.HPABSORB) {
            text = StringTable.WeaponOption_HpAbsorb;
        } else if (option === WeaponOption.NOGUARD) {
            text = StringTable.WeaponOption_NoGuard;
        } else if (option === WeaponOption.HPMINIMUM) {
            text = StringTable.WeaponOption_HpMinimum;
        } else if (option === WeaponOption.HALVEATTACK) {
            text = StringTable.WeaponOption_HalveAttack;
        } else if (option === WeaponOption.HALVEATTACKBREAK) {
            text = StringTable.WeaponOption_HalveAttackBreak;
        } else if (option === WeaponOption.SEALATTACK) {
            text = StringTable.WeaponOption_SealAttack;
        } else if (option === WeaponOption.SEALATTACKBREAK) {
            text = StringTable.WeaponOption_SealAttackBreak;
        } else {
            text = '';
        }

        return text;
    }
});

ItemSentence.Skill = defineObject(BaseItemSentence, {
    drawItemSentence: function (x, y, item) {
        var refList = item.getSkillReferenceList();
        var renderer = FotF_CusparaRenderer;

        if (this.getItemSentenceCount(item) === 0) {
            return 0;
        }

        x += renderer.drawText(x, y, root.queryCommand('skill_object'));
        ItemInfoRenderer.drawList(x, y, refList);
    },

    getItemSentenceCount: function (item) {
        var refList = item.getSkillReferenceList();

        return refList.getTypeCount() - refList.getHiddenCount();
    }
});

ItemSentence.Bonus = defineObject(BaseItemSentence, {
    drawItemSentence: function (x, y, item) {
        var i, n;
        var count = ParamGroup.getParameterCount();
        var renderer = FotF_CusparaRenderer;

        for (i = 0; i < count; i++) {
            n = ParamGroup.getParameterBonus(item, i);
            if (n !== 0) {
                break;
            }
        }

        if (i === count) {
            return 0;
        }

        x += renderer.drawText(x, y, root.queryCommand('support_capacity'));
        ItemInfoRenderer.drawDoping(x, y, item, true);
    },

    getItemSentenceCount: function (item) {
        return ItemInfoRenderer.getDopingCount(item, true);
    }
});

/*-------------------------------------------------------------
                      ITEM INFO OVERRIDES
Similar to item sentences, I overwrote ALL item info objects to
make them use the new renderer as well. I improved some of them
by adding or clarifying information.
-------------------------------------------------------------*/

(function () {
    ClassChangeItemInfo = defineObject(BaseItemInfo, {
        _arr: null,

        setInfoItem: function (item) {
            var i, count, classGroup, name;
            var info = item.getClassChangeInfo();

            this._arr = [];

            BaseItemInfo.setInfoItem.call(this, item);

            if (info.isClassInfoDisplayable()) {
                // Class group can be supposed to have the same name,
                // set things excluding duplication in the _arr.
                count = info.getClassGroupCount();
                for (i = 0; i < count; i++) {
                    classGroup = info.getClassGroupData(i);
                    name = classGroup.getName();

                    if (this._arr.indexOf(name) !== -1) {
                        continue;
                    }

                    this._arr.push(name);
                }
            }
        },

        drawItemInfoCycle: function (x, y) {
            if (this._arr.length > 0) {
                this._drawList(x, y);
            }
        },

        getInfoPartsCount: function () {
            return this._arr.length;
        },

        _drawList: function (x, y, list) {
            var i;
            var count = this._arr.length;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, StringTable.ItemInfo_ClassChange);

            for (i = 0; i < count; i++) {
                renderer.drawName(x, y, this._arr[i]);
                y += ItemInfoRenderer.getSpaceY();
            }
        }
    });

    DamageItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var damageInfo = this._item.getDamageInfo();
            var damageType = damageInfo.getDamageType();
            var hit = damageInfo.getHit();
            var colorIndex = 3;

            if (damageType === DamageType.PHYSICS) {
                colorIndex = 1;
            } else if (damageType === DamageType.MAGIC) {
                colorIndex = 2;
            }

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Damage));
            x += cfg.itemStatSpacingX;

            x += renderer.drawText(x, y, this._getName());
            x += renderer.drawNumber(x, y, damageInfo.getDamageValue(), null, colorIndex);
            x += cfg.itemStatSpacingX;

            x += renderer.drawText(x, y, root.queryCommand('hit_capacity'));
            if (hit > 0) {
                x += renderer.drawNumber(x, y, hit, null, null);
            } else {
                x += renderer.drawSign(x, y, StringTable.SignWord_Limitless);
            }
        },

        getInfoPartsCount: function () {
            return 1;
        },

        _getName: function () {
            return root.queryCommand('power_capacity');
        }
    });

    DopingItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Doping));
            x += cfg.itemStatSpacingX;

            ItemInfoRenderer.drawDoping(x, y, this._item, false);
        },

        getInfoPartsCount: function () {
            return ItemInfoRenderer.getDopingCount(this._item, false);
        }
    });

    DurabilityItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var type = this._item.getDurabilityInfo().getDurabilityChangeType();
            var arr = [StringTable.DurabilityType_Max, StringTable.DurabilityType_Half, StringTable.DurabilityType_Break];

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Durability));
            x += cfg.itemStatSpacingX;

            x += renderer.drawText(x, y, arr[type]);
            x += cfg.itemStatSpacingX;

            this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    EntireRecoveryItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var recoveryInfo = this._item.getEntireRecoveryInfo();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_EntireRecovery));
            x += cfg.itemStatSpacingX;

            if (recoveryInfo.getRecoveryType() === RecoveryType.SPECIFY) {
                x += renderer.drawText(x, y, StringTable.Recovery_Value);
                x += renderer.drawNumber(x, y, recoveryInfo.getRecoveryValue(), null, 4);
            } else {
                x += renderer.drawText(x, y, StringTable.Recovery_All);
            }
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    FusionItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var renderer = FotF_CusparaRenderer;
            var fusionInfo = this._item.getFusionInfo();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Fusion));
            x += renderer.drawInvocation(x, y, fusionInfo.getFusionData(), fusionInfo.getInvocationValue(), fusionInfo.getInvocationType());
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    KeyItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var keyInfo = this._item.getKeyInfo();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Key));

            x += renderer.drawText(x, y, StringTable.Key_Target);
            x += cfg.itemStatSpacingX;

            if (keyInfo.getKeyFlag() & KeyFlag.GATE) {
                x += renderer.drawText(x, y, StringTable.Key_Gate);
                x += cfg.itemStatSpacingX;
            }

            if (keyInfo.getKeyFlag() & KeyFlag.TREASURE) {
                x += renderer.drawText(x, y, StringTable.Key_Treasure);
                x += cfg.itemStatSpacingX;
            }

            if (!KeyEventChecker.isPairKey(this._item)) {
                this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
            }
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    MetamorphozeItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var i;
            var renderer = FotF_CusparaRenderer;
            var refList = this._item.getMetamorphozeInfo().getMetamorphozeReferenceList();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Metamorphoze));

            for (i = 0; i < refList.getTypeCount(); i++) {
                var name = refList.getTypeData(i).getName();
                renderer.drawName(x, y, name);
                y += ItemInfoRenderer.getSpaceY();
            }
        },

        getInfoPartsCount: function () {
            var refList = this._item.getMetamorphozeInfo().getMetamorphozeReferenceList();
            return refList.getTypeCount() !== 0 ? refList.getTypeCount() : 1;
        }
    });

    QuickItemInfo = defineObject(BaseItemInfo, {
        _isSurroundings: false,

        setInfoItem: function (item) {
            BaseItemInfo.setInfoItem.call(this, item);
            this._isSurroundings = item.getQuickInfo().getValue() === QuickValue.SURROUNDINGS;
        },

        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Quick));
            x += cfg.itemStatSpacingX;

            x += this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
            x += cfg.itemStatSpacingX;

            if (this._isSurroundings) {
                x += cfg.itemStatSpacingX;
                renderer.drawText(x, y, StringTable.QuickInfo_Surroundings);
            }
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    RecoveryItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var recoveryInfo = this._item.getRecoveryInfo();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Recovery));
            x += cfg.itemStatSpacingX;

            if (recoveryInfo.getRecoveryType() === RecoveryType.SPECIFY) {
                x += renderer.drawNumber(x, y, recoveryInfo.getRecoveryValue(), null, 4);
            } else {
                x += renderer.drawText(x, y, StringTable.Recovery_All);
            }

            x += cfg.itemStatSpacingX;
            this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    RescueItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Rescue));
            x += cfg.itemStatSpacingX;

            this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    ResurrectionItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var type = this._item.getResurrectionInfo().getResurrectionType();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Resurrection));
            x += cfg.itemStatSpacingX;

            if (type === ResurrectionType.MIN) {
                x += renderer.drawNumber(x, y, 1, null, null);
                renderer.drawText(x, y, 'HP');
            } else if (type === ResurrectionType.HALF) {
                renderer.drawText(x, y, 'Half HP');
            } else {
                renderer.drawText(x, y, 'Full HP');
            }
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    SkillChangeItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var info = this._item.getSkillChangeInfo();
            var type = info.getSkillControlType();
            var skill = info.getSkill();
            var text = '';

            if (type === IncreaseType.INCREASE) {
                x += renderer.drawText(x, y, 'Learn skill');
                renderer.drawName(x, y, skill.getName());
            } else if (type === IncreaseType.DECREASE) {
                x += renderer.drawText(x, y, 'Forget skill');
                renderer.drawName(x, y, skill.getName());
            } else {
                renderer.drawText(x, y, 'Forget all skills');
            }
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    StateItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var stateInvocation = this._item.getStateInfo().getStateInvocation();
            var state = stateInvocation.getState();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_State));
            x += cfg.itemStatSpacingX;

            x += renderer.drawInvocation(x, y, state, stateInvocation.getInvocationValue(), stateInvocation.getInvocationType());
            x += cfg.itemStatSpacingX;

            this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    StateRecoveryItemInfo = defineObject(BaseItemInfo, {
        _stateCount: 0,

        setInfoItem: function (item) {
            this._stateCount = ItemInfoRenderer.getStateCount(item.getStateRecoveryInfo().getStateGroup());
            BaseItemInfo.setInfoItem.call(this, item);
        },

        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_StateRecovery));
            x += cfg.itemStatSpacingX;

            x += this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
            x += cfg.itemStatSpacingX;

            ItemInfoRenderer.drawState(x, y, this._item.getStateRecoveryInfo().getStateGroup(), true);
        },

        getInfoPartsCount: function () {
            return this._stateCount;
        }
    });

    StealItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var info = this._item.getStealInfo();
            var flag = info.getStealFlag();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Steal));
            x += cfg.itemStatSpacingX;

            x += this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
            x += cfg.itemStatSpacingX;

            if (flag & StealFlag.SPEED) {
                renderer.drawText(x, y, 'If faster than opponent');
                y += cfg.lineSpacingY;
            }
            if (flag & StealFlag.WEIGHT) {
                renderer.drawText(x, y, 'If item is not too heavy');
                y += cfg.lineSpacingY;
            }
            if (flag & StealFlag.WEAPON) {
                renderer.drawText(x, y, 'Can steal weapons');
                y += cfg.lineSpacingY;
            }
            if (flag & StealFlag.MULTI) {
                renderer.drawText(x, y, 'Can steal multiple items');
                y += cfg.lineSpacingY;
            }
        },

        getInfoPartsCount: function () {
            var n = 0;
            var info = this._item.getStealInfo();
            var flag = info.getStealFlag();

            if (flag & StealFlag.SPEED) {
                n++;
            }
            if (flag & StealFlag.WEIGHT) {
                n++;
            }
            if (flag & StealFlag.WEAPON) {
                n++;
            }
            if (flag & StealFlag.MULTI) {
                n++;
            }

            return n !== 0 ? n : 1;
        }
    });

    SwitchItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var renderer = FotF_CusparaRenderer;

            renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Switch));
        },

        getInfoPartsCount: function () {
            return 1;
        },

        validateItem: function (itemTargetInfo) {
            return true;
        }
    });

    TeleportationItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var teleportationInfo = this._item.getTeleportationInfo();

            x += renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Teleportation));
            x += cfg.itemStatSpacingX;

            x += renderer.drawText(x, y, 'Selection');

            if (teleportationInfo.getRangeType() === SelectionRangeType.ALL) {
                x += renderer.drawText(x, y, StringTable.Range_All);
            } else {
                x += renderer.drawNumber(x, y, teleportationInfo.getRangeValue(), null, null);
            }

            x += cfg.itemStatSpacingX;
            this.drawRange(x, y, this._item.getRangeValue(), this._item.getRangeType());
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });

    UnusableItemInfo = defineObject(BaseItemInfo, {
        drawItemInfoCycle: function (x, y) {
            var renderer = FotF_CusparaRenderer;

            renderer.drawText(x, y, this.getItemTypeName(StringTable.ItemInfo_Unusable));
        },

        getInfoPartsCount: function () {
            return 1;
        }
    });
})();

/*-------------------------------------------------------------
                            ALIAS
-------------------------------------------------------------*/

(function () {
    //Increase skill info window width
    var FotF_ExtendSkillInfoWidth = SkillInfoWindow.getWindowWidth;
    SkillInfoWindow.getWindowWidth = function () {
        return FotF_ExtendSkillInfoWidth.call(this) + FotF_CusparaRenderSettings.extraSkillInfoSpacingX;
    };

    //Increase skill info window height
    var FotF_ProlongSkillInfoWindow = SkillInfoWindow.getWindowHeight;
    SkillInfoWindow.getWindowHeight = function () {
        //Sometimes the skill isn't set when hovering too early
        if (this._skill === null) {
            return 0;
        }
        var height = FotF_ProlongSkillInfoWindow.call(this);
        var count = FotF_CusparaRenderer.getSentenceCount(this._skill, ObjectType.SKILL) + 1;

        return height + count * ItemInfoRenderer.getSpaceY();
    };

    //Cache skill description to prevent critical CPU load (line breaks are expensive)
    var FotF_CacheSkillDescription = SkillInfoWindow.setSkillInfoData;
    SkillInfoWindow.setSkillInfoData = function (skill, objecttype) {
        FotF_CacheSkillDescription.call(this, skill, objecttype);

        if (skill === null) {
            return;
        }

        var cfg = FotF_CusparaRenderSettings;
        var font = root.getBaseData().getFontList().getDataFromId(cfg.descriptionFontId);
        var type = ObjectType.SKILL;
        this._description = skill.getDescription();

        if (TextRenderer.getTextWidth(this._description, font) > FotF_CusparaRenderer.getMaxDescriptionWidth(type)) {
            var textLineArray = FotF_TextControlV2.convertTextToLineArray(this._description, font, FotF_CusparaRenderer.getMaxDescriptionWidth(type));
            this._description = FotF_TextControlV2.convertLineArrayToLineBreakText(textLineArray);
        }
    };

    //Increase terrain info window width
    var FotF_ExtendTerrainWindowWidth = MapParts.Terrain._getWindowWidth;
    MapParts.Terrain._getWindowWidth = function () {
        return FotF_ExtendTerrainWindowWidth.call(this) + FotF_CusparaRenderSettings.extraTerrainInfoSpacingX;
    };

    //Increase item info window width
    var FotF_ExtendItemWindowWidth = ItemInfoWindow.getWindowWidth;
    ItemInfoWindow.getWindowWidth = function () {
        return FotF_ExtendItemWindowWidth.call(this) + FotF_CusparaRenderSettings.extraItemInfoSpacingX;
    };

    //Cache item description to prevent critical CPU load (line breaks are expensive)
    var FotF_CacheItemDescription = ItemInfoWindow.setInfoItem;
    ItemInfoWindow.setInfoItem = function (item) {
        FotF_CacheItemDescription.call(this, item);

        if (item === null) {
            return;
        }

        var cfg = FotF_CusparaRenderSettings;
        var font = root.getBaseData().getFontList().getDataFromId(cfg.descriptionFontId);
        var type = item.isWeapon() ? ObjectType.WEAPON : ObjectType.ITEM;
        this._description = item.getDescription();

        if (TextRenderer.getTextWidth(this._description, font) > FotF_CusparaRenderer.getMaxDescriptionWidth(type)) {
            var textLineArray = FotF_TextControlV2.convertTextToLineArray(this._description, font, FotF_CusparaRenderer.getMaxDescriptionWidth(type));
            this._description = FotF_TextControlV2.convertLineArrayToLineBreakText(textLineArray);
        }
    };
})();

/*-------------------------------------------------------------
                        OVERRIDES/NEW
-------------------------------------------------------------*/

(function () {
    //Disable bottom description window if set in config
    if (FotF_CusparaRenderSettings.disableBottomDescriptionWindow) {
        UnitMenuScreen.drawScreenBottomText = function () {};
    }

    //Synchronize line spacings
    ItemInfoRenderer.getSpaceY = function () {
        return FotF_CusparaRenderSettings.lineSpacingY;
    };

    //Synchronize line spacings
    BaseMapParts.getIntervalY = function () {
        return FotF_CusparaRenderSettings.lineSpacingY;
    };

    //Synchronize item drawing spacing
    BaseItemSentence._getMiddleSpace = function () {
        return FotF_CusparaRenderSettings.itemStatSpacingX;
    };

    //Modify weapon info sentences
    ItemInfoWindow._configureWeapon = function (groupArray) {
        groupArray.appendObject(ItemSentence.Title);
        groupArray.appendObject(ItemSentence.CombatStats);
        groupArray.appendObject(ItemSentence.AdditionState);
        groupArray.appendObject(ItemSentence.WeaponOption);
        groupArray.appendObject(ItemSentence.Effective);
        groupArray.appendObject(ItemSentence.Skill);
        groupArray.appendObject(ItemSentence.Only);
        groupArray.appendObject(ItemSentence.Bonus);
        groupArray.appendObject(ItemSentence.Cuspara);
    };

    //Modify item info sentences, add AOE sentence
    ItemInfoWindow._configureItem = function (groupArray) {
        groupArray.appendObject(ItemSentence.Title);
        groupArray.appendObject(ItemSentence.AOE);
        groupArray.appendObject(ItemSentence.WeaponLevelAndWeight);
        groupArray.appendObject(ItemSentence.Info);
        groupArray.appendObject(ItemSentence.ResistState);
        groupArray.appendObject(ItemSentence.Skill);
        groupArray.appendObject(ItemSentence.Target);
        groupArray.appendObject(ItemSentence.Only);
        groupArray.appendObject(ItemSentence.Bonus);
        groupArray.appendObject(ItemSentence.Cuspara);
    };

    //Synchronize drawing methods
    AggregationViewer.drawAggregationViewer = function (x, y, name) {
        if (this._arr.length === 0) {
            return 0;
        }

        var renderer = FotF_CusparaRenderer;

        x += renderer.drawText(x, y, name);
        x += BaseItemSentence._getMiddleSpace();
        this._drawList(x, y);
    };

    //Synchronize drawing methods
    AggregationViewer._drawList = function (x, y) {
        var i, obj, name, objecttype, suffix;
        var count = this._arr.length;
        var renderer = FotF_CusparaRenderer;

        for (i = 0; i < count; i++) {
            obj = this._arr[i];
            name = obj.name;
            objecttype = obj.objecttype;

            if (objecttype === ObjectType.WEAPON) {
                suffix = StringTable.Aggregation_SuffixEquipment;
            } else if (objecttype === ObjectType.ITEM || objecttype === ObjectType.SKILL) {
                suffix = StringTable.Aggregation_SuffixPossession;
            } else if (objecttype === ObjectType.STATE) {
                suffix = StringTable.Aggregation_SuffixAddition;
            } else {
                suffix = '';
            }

            x += renderer.drawName(x, y, name);
            x += renderer.drawText(x, y, suffix);
            y += ItemInfoRenderer.getSpaceY();
        }
    };

    //Synchronize drawing methods
    ItemInfoRenderer.drawList = function (x, y, refList) {
        var i, data;
        var count = refList.getTypeCount();
        var objectType = refList.getObjectType();
        var isCheck = false;
        var renderer = FotF_CusparaRenderer;

        if (objectType === ObjectType.SKILL || objectType === ObjectType.STATE) {
            isCheck = true;
        }

        // The length of the name is not the same, so it's difficult to do multiple drawings on the same line.
        // So the line increases according to the number of the name.
        for (i = 0; i < count; i++) {
            data = refList.getTypeData(i);
            if (!isCheck || !data.isHidden()) {
                renderer.drawName(x, y, data.getName());
                y += this.getSpaceY();
            }
        }
    };

    //Synchronize drawing methods
    ItemInfoRenderer.drawDoping = function (x, y, item, isParameter) {
        var i, n, text;
        var count = ParamGroup.getParameterCount();
        var count2 = 0;
        var xBase = x;
        var renderer = FotF_CusparaRenderer;

        for (i = 0; i < count; i++) {
            if (isParameter) {
                n = ParamGroup.getParameterBonus(item, i);
            } else {
                n = ParamGroup.getDopingParameter(item, i);
            }

            if (n !== 0) {
                text = ParamGroup.getParameterName(i);
                x += renderer.drawText(x, y, text);
                x += renderer.drawSign(x, y, n > 0 ? '+' : '-');

                if (n < 0) {
                    n *= -1;
                }

                x += renderer.drawNumber(x, y, n, null, null);
                y += this.getSpaceY();

                count2++;
                x = xBase;
            }
        }

        return count2;
    };

    //Synchronize drawing methods
    ItemInfoRenderer.drawState = function (x, y, stateGroup, isRecovery) {
        var text;
        var renderer = FotF_CusparaRenderer;

        if (this.getStateCount(stateGroup) === 0) {
            return;
        }

        if (isRecovery) {
            text = StringTable.State_Recovery;
        } else {
            text = StringTable.State_Regist;
        }

        x += renderer.drawText(x, y, text);

        if (stateGroup.isAllBadState()) {
            x += renderer.drawText(x, y, StringTable.State_AllBadState);
        } else {
            ItemInfoRenderer.drawList(x, y, stateGroup.getStateReferenceList());
        }
    };

    //Coordinate skill info drawing
    SkillInfoWindow.drawWindowContent = function (x, y) {
        var text, skillText, count;
        var renderer = FotF_CusparaRenderer;
        var cfg = FotF_CusparaRenderSettings;
        var custom = this._skill.custom;
        var interval = FotF_CusparaRenderSettings.lineSpacingY;
        var baseX = x;

        if (this._skill === null) {
            return;
        }

        var handle = this._skill.getIconResourceHandle();

        if (handle !== null) {
            GraphicsRenderer.drawImage(x, y, handle, GraphicsType.ICON);
            x += GraphicsFormat.ICON_WIDTH + cfg.bigIconSpacingX;
        }

        x += renderer.drawTitle(x, y + cfg.titleOffsetY, this._skill.getName());
        y += GraphicsFormat.ICON_HEIGHT + cfg.bigIconSpacingY;
        x = baseX;

        if (this._isInvocationType()) {
            x += renderer.drawText(x, y, StringTable.SkillWord_Invocation);
            x += renderer.drawInvocation(x, y, null, this._skill.getInvocationValue(), this._skill.getInvocationType());

            y += interval;
            x = baseX;
        }

        if (this._aggregationViewer !== null) {
            count = this._aggregationViewer.getAggregationViewerCount();
            if (count !== 0) {
                this._aggregationViewer.drawAggregationViewer(x, y, this._getMatchName());
                y += interval * this._aggregationViewer.getAggregationViewerCount();
            }
        }

        text = this._getSkillTypeText();
        if (text !== '') {
            skillText = root.queryCommand('skill_object');
            renderer.drawText(x, y, text + ' ' + skillText);
        } else {
            text = this._getCategoryText();
            renderer.drawText(x, y, text);
        }

        y += interval;

        for (string in custom) {
            var obj = FotF_CusparaRenderer.checkObject(this._skill, string, ObjectType.SKILL);

            if (typeof obj === 'undefined') {
                continue;
            }

            FotF_CusparaRenderer.drawContent(x, y, obj, this._skill);
            y += interval * FotF_CusparaRenderer.getCustomSpacing(obj, this._skill);
        }

        var obj2 = FotF_CusparaRenderer.checkKeywordDictionary(this._skill);

        if (typeof obj2 !== 'undefined') {
            FotF_CusparaRenderer.drawContent(x, y, obj2, this._skill);
            y += interval * FotF_CusparaRenderer.getCustomSpacing(obj2, this._skill);
        }

        if (cfg.drawDescriptionInInfoWindows) {
            if (typeof this._description !== 'string') {
                var font = root.getBaseData().getFontList().getDataFromId(cfg.descriptionFontId);
                this._description = this._skill.getDescription();
                if (TextRenderer.getTextWidth(this._description, font) > FotF_CusparaRenderer.getMaxDescriptionWidth(ObjectType.SKILL)) {
                    var textLineArray = FotF_TextControlV2.convertTextToLineArray(this._description, font, FotF_CusparaRenderer.getMaxDescriptionWidth(ObjectType.SKILL));
                    this._description = FotF_TextControlV2.convertLineArrayToLineBreakText(textLineArray);
                }
            }
            FotF_CusparaRenderer.drawDescription(x, y, this._description);
        }
    };

    MapParts.Terrain._drawContent = function (x, y, terrain) {
        if (terrain === null) {
            return;
        }

        var text;
        var cfg = FotF_CusparaRenderSettings;
        var renderer = FotF_CusparaRenderer;
        var custom = terrain.custom;
        var xCursor = this.getMapPartsX();
        var yCursor = this.getMapPartsY();
        var terrainHandle = root.getCurrentSession().getMapChipGraphicsHandle(xCursor, yCursor, true);
        var baseX = x;

        var pic = terrain.getMapChipImage();

        if (terrainHandle !== null && pic !== null) {
            var width = GraphicsFormat.MAPCHIP_WIDTH;
            var height = GraphicsFormat.MAPCHIP_HEIGHT;
            pic.drawStretchParts(x, y, GraphicsFormat.ICON_WIDTH, GraphicsFormat.ICON_HEIGHT, terrainHandle.getSrcX() * width, terrainHandle.getSrcY() * height, width, height);
            x += GraphicsFormat.ICON_WIDTH + cfg.bigIconSpacingX;
        }

        x += renderer.drawTitle(x, y + cfg.titleOffsetY, terrain.getName());
        y += GraphicsFormat.ICON_HEIGHT + cfg.bigIconSpacingY;
        x = baseX;

        x += renderer.drawText(x, y, root.queryCommand('avoid_capacity'));
        x += renderer.drawSign(x, y, terrain.getAvoid() >= 0 ? '+' : '-');
        x += renderer.drawNumber(x, y, terrain.getAvoid(), null, null);
        y += cfg.lineSpacingY;

        if (terrain.getDef() !== 0) {
            x = baseX;
            text = ParamGroup.getParameterName(ParamGroup.getParameterIndexFromType(ParamType.DEF));
            x += renderer.drawText(x, y, text);
            x += renderer.drawSign(x, y, terrain.getDef() >= 0 ? '+' : '-');
            x += renderer.drawNumber(x, y, terrain.getDef(), null, null);
            y += cfg.lineSpacingY;
        }

        if (terrain.getMdf() !== 0) {
            x = baseX;
            text = ParamGroup.getParameterName(ParamGroup.getParameterIndexFromType(ParamType.MDF));
            x += renderer.drawText(x, y, text);
            x += renderer.drawSign(x, y, terrain.getMdf() >= 0 ? '+' : '-');
            x += renderer.drawNumber(x, y, terrain.getMdf(), null, null);
            y += cfg.lineSpacingY;
        }

        if (terrain.getAutoRecoveryValue() !== 0) {
            x = baseX;
            text = FotF_CusparaRenderSettings.terrainRecoveryString;
            x += renderer.drawText(x, y, text);
            x += renderer.drawSign(x, y, terrain.getAutoRecoveryValue() >= 0 ? '+' : '-');
            x += renderer.drawNumber(x, y, terrain.getAutoRecoveryValue(), null, null);
            y += cfg.lineSpacingY;
        }

        x = baseX;

        for (string in custom) {
            var obj = FotF_CusparaRenderer.checkObject(terrain, string, ObjectType.TERRAIN);

            if (typeof obj === 'undefined') {
                continue;
            }

            FotF_CusparaRenderer.drawContent(x, y, obj, terrain);
            y += cfg.lineSpacingY * FotF_CusparaRenderer.getCustomSpacing(obj, terrain);
        }
    };

    MapParts.Terrain._getWindowHeight = function () {
        var xCursor = this.getMapPartsX();
        var yCursor = this.getMapPartsY();
        var terrain = PosChecker.getTerrainFromPos(xCursor, yCursor);

        if (terrain === null) {
            return 0;
        }

        return this._getPartsCount(terrain) * this.getIntervalY() + this._getWindowYPadding();
    };

    MapParts.Terrain._getPartsCount = function (terrain) {
        //var count = FotF_ProlongTerrainWindow.call(this, terrain);
        var count = 1;

        if (terrain.getDef() !== 0) {
            count++;
        }

        if (terrain.getMdf() !== 0) {
            count++;
        }

        if (terrain.getAutoRecoveryValue() !== 0) {
            count++;
        }

        count += FotF_CusparaRenderer.getTitleHeight(1);
        count += FotF_CusparaRenderer.getSentenceCount(terrain, ObjectType.TERRAIN);

        if (terrain.getAutoRecoveryValue() !== 0) {
            count++;
        }

        return count;
    };

    //AOE item sentence
    ItemSentence.AOE = defineObject(BaseItemSentence, {
        drawItemSentence: function (x, y, item) {
            if (!item.custom.aoe) {
                return;
            }

            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var weapon = AoeParameterInterpreter.getWeapon(item, false);
            var selectionRangeType = AoeParameterInterpreter.getSelectionRangeType(item);
            var effectRangeType = AoeParameterInterpreter.getEffectRangeType(item);
            var selectionRange = AoeDictionary[selectionRangeType].name;
            var effectRange = AoeDictionary[effectRangeType].name;

            var savedX = x;

            var text = root.queryCommand('attack_capacity');
            x += renderer.drawText(x, y, text);
            x += renderer.drawNumber(x, y, weapon.getPow(), weapon, null);
            x += cfg.itemStatSpacingX;

            text = root.queryCommand('hit_capacity');
            x += renderer.drawText(x, y, text);
            x += renderer.drawNumber(x, y, weapon.getHit(), null, null);
            x += cfg.itemStatSpacingX;

            text = root.queryCommand('critical_capacity');
            x += renderer.drawText(x, y, text);
            x += renderer.drawNumber(x, y, weapon.getCritical(), null, null);
            x += cfg.itemStatSpacingX;

            text = root.queryCommand('range_capacity');
            x += renderer.drawText(x, y, text);
            x += renderer.drawNumber(x, y, selectionRange, null, null);

            x = savedX;
            y += cfg.lineSpacingY;

            x += renderer.drawText(x, y, 'AOE Attack');
            x += renderer.drawName(x, y, effectRange);

            if (typeof FotF_ElementRenderer === 'object' && weapon.custom.element) {
                x = savedX;
                y += cfg.lineSpacingY;
                FotF_ElementRenderer.drawElement(x, y, weapon);
            }

            if (typeof item.custom.aoe.stateId === 'number') {
                var state = root.getBaseData().getStateList().getDataFromId(item.custom.aoe.stateId);
                x = savedX;
                y += cfg.lineSpacingY;
                x += renderer.drawText(x, y, 'Inflicts');
                x += renderer.drawName(x, y, state.getName());
            }
        },

        getItemSentenceCount: function (item) {
            if (!item.custom.aoe) {
                return 0;
            }

            var n = 2;
            var weapon = AoeParameterInterpreter.getWeapon(item, false);

            if (typeof item.custom.aoe.stateId === 'number') {
                n++;
            }

            if (weapon !== null && typeof FotF_ElementRenderer === 'object' && weapon.custom.element) {
                n++;
            }

            return n;
        }
    });

    //Synchronize drawing methods
    BaseItemInfo.drawRange = function (x, y, rangeValue, rangeType) {
        var renderer = FotF_CusparaRenderer;
        var baseX = x;

        x += renderer.drawText(x, y, root.queryCommand('range_capacity'));

        if (rangeType === SelectionRangeType.SELFONLY) {
            x += renderer.drawText(x, y, StringTable.Range_Self);
        } else if (rangeType === SelectionRangeType.MULTI) {
            x += renderer.drawNumber(x, y, rangeValue, null, null);
        } else if (rangeType === SelectionRangeType.ALL) {
            x += renderer.drawText(x, y, StringTable.Range_All);
        }

        return x - baseX;
    };
})();

/*-------------------------------------------------------------
                            WRAPPER
-------------------------------------------------------------*/

//Centralized render wrapper, accessible from anywhere
//Use these functions if possible, to achieve uniform drawing
var FotF_CusparaRenderer = {
    drawContent: function (x, y, cont, obj, unit) {
        if (typeof cont === 'undefined' || obj === null) {
            return;
        }

        var savedX = x;
        x = savedX;

        var desc = this.getDescription(cont, obj);
        var desc2 = this.getDescription2(cont, obj);
        var value = this.getValue(cont, obj);

        if (typeof desc === 'string') {
            x += this.drawText(x, y, desc);
        } else if (typeof desc === 'function') {
            var text = desc(cont, obj);
            x += this.drawText(x, y, text);
        }

        if (typeof value === 'string') {
            x += this.drawName(x, y, value);
        } else if (typeof value === 'number') {
            x += this.drawNumber(x, y, value, null, null);
        }

        if (typeof desc2 === 'string') {
            x += this.drawText(x, y, desc2);
        } else if (typeof desc2 === 'function') {
            var text = desc2(cont, obj);
            x += this.drawText(x, y, text);
        }

        var drawFunction = this.getDrawFunction(cont);

        //The unit parameter can only be used by states, and only if prepared that way!
        if (typeof drawFunction === 'function') {
            x = savedX;
            drawFunction(x, y, cont, obj, unit);
        }
    },

    drawTitle: function (x, y, text) {
        var cfg = FotF_CusparaRenderSettings;
        var font = root.getBaseData().getFontList().getDataFromId(cfg.titleFontId);
        var color = cfg.titleColor;
        var alpha = cfg.titleAlpha;

        TextRenderer.drawAlphaText(x, y, text, -1, color, alpha, font);

        return TextRenderer.getTextWidth(text, font) + cfg.titleFontSpacing;
    },

    drawText: function (x, y, text) {
        var cfg = FotF_CusparaRenderSettings;
        var font = root.getBaseData().getFontList().getDataFromId(cfg.stringFontId);
        var color = cfg.stringColor;
        var alpha = cfg.stringAlpha;

        TextRenderer.drawAlphaText(x, y, text, -1, color, alpha, font);

        return TextRenderer.getTextWidth(text, font) + cfg.stringFontSpacing;
    },

    drawName: function (x, y, text) {
        var cfg = FotF_CusparaRenderSettings;
        var font = root.getBaseData().getFontList().getDataFromId(cfg.nameFontId);
        var color = cfg.nameColor;
        var alpha = cfg.nameAlpha;

        TextRenderer.drawAlphaText(x, y, text, -1, color, alpha, font);

        return TextRenderer.getTextWidth(text, font) + cfg.nameFontSpacing;
    },

    drawNumber: function (x, y, value, obj, index) {
        var cfg = FotF_CusparaRenderSettings;
        var font = root.getBaseData().getFontList().getDataFromId(cfg.numberFontId);
        var color = this.getNumberColor(obj, index);
        var alpha = cfg.numberAlpha;

        TextRenderer.drawAlphaText(x, y, value.toString(), -1, color, alpha, font);

        return TextRenderer.getTextWidth(value.toString(), font) + cfg.numberFontSpacing;
    },

    drawSign: function (x, y, text) {
        var cfg = FotF_CusparaRenderSettings;
        var font = root.getBaseData().getFontList().getDataFromId(cfg.signFontId);
        var color = cfg.signColor;
        var alpha = cfg.signAlpha;

        TextRenderer.drawAlphaText(x, y, text, -1, color, alpha, font);

        return TextRenderer.getTextWidth(text, font) + cfg.signFontSpacing;
    },

    drawIcon: function (x, y, icon) {
        if (icon === null) {
            return 0;
        }

        var cfg = FotF_CusparaRenderSettings;

        icon.drawStretchParts(x, y + cfg.iconOffsetY, cfg.iconWidth, cfg.iconHeight, 0, 0, icon.getWidth(), icon.getHeight());

        return cfg.iconWidth + cfg.iconSpacingX;
    },

    drawDescription: function (x, y, text) {
        var cfg = FotF_CusparaRenderSettings;
        var font = root.getBaseData().getFontList().getDataFromId(cfg.descriptionFontId);
        var color = cfg.descriptionColor;
        var alpha = cfg.descriptionAlpha;

        TextRenderer.drawAlphaText(x, y, text, -1, color, alpha, font);

        return TextRenderer.getTextWidth(text, font) + cfg.descriptionFontSpacing;
    },

    drawInvocation: function (x, y, obj, value, type) {
        var text;
        var renderer = FotF_CusparaRenderer;
        var baseX = x;

        if (obj !== null) {
            x += renderer.drawName(x, y, obj.getName());
        }

        if (type === InvocationType.HPDOWN) {
            x += renderer.drawText(x, y, 'while under');
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
            x += renderer.drawText(x, y, 'MHP');
        } else if (type === InvocationType.ABSOLUTE) {
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
        } else {
            if (type === InvocationType.LV) {
                text = StringTable.Status_Level;
            } else {
                text = ParamGroup.getParameterName(ParamGroup.getParameterIndexFromType(type));
            }

            value *= 100;

            x += renderer.drawSign(x, y, '[');
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
            x += renderer.drawText(x, y, text);
            x += renderer.drawSign(x, y, ']');
        }

        return x - baseX;
    },

    getNumberColor: function (item, index) {
        var cfg = FotF_CusparaRenderSettings;
        var autoIndex = this.getColorIndexFromItem(item);

        if (autoIndex !== null) {
            index = autoIndex;
        }

        if (index === 0) {
            return cfg.numberColorDefault;
        } else if (index === 1) {
            return cfg.numberColorPhysical;
        } else if (index === 2) {
            return cfg.numberColorMagic;
        } else if (index === 3) {
            return cfg.numberColorTrue;
        } else if (index === 4) {
            return cfg.numberColorHealing;
        }

        return cfg.numberColorDefault;
    },

    getColorIndexFromItem: function (item) {
        if (typeof item !== 'object' || item === null) {
            return null;
        }

        if (item.isWeapon()) {
            if (Miscellaneous.isPhysicsBattle(item)) {
                return 1;
            } else {
                return 2;
            }
        } else if (item.getItemType() === ItemType.DAMAGE) {
            if (item.getDamageInfo().getDamageType() === DamageType.PHYSICS) {
                return 1;
            } else if (item.getDamageInfo().getDamageType() === DamageType.MAGIC) {
                return 2;
            } else if (item.getDamageInfo().getDamageType() === DamageType.FIXED) {
                return 3;
            }
        }

        return null;
    },

    getDictionaryByType: function (objectType) {
        if (objectType === ObjectType.ITEM) {
            return FotF_ItemCusparaDictionary;
        } else if (objectType === ObjectType.WEAPON) {
            return FotF_WeaponCusparaDictionary;
        } else if (objectType === ObjectType.SKILL) {
            return FotF_SkillCusparaDictionary;
        } else if (objectType === ObjectType.STATE) {
            return FotF_StateCusparaDictionary;
        } else if (objectType === ObjectType.TERRAIN) {
            return FotF_TerrainCusparaDictionary;
        }

        return {};
    },

    checkCustomKeyword: function (obj, dict) {
        var keyword = obj.getCustomKeyword();
        var cont = dict[keyword];

        return cont;
    },

    checkKeywordDictionary: function (obj) {
        for (string in FotF_CustomKeywordDictionary) {
            var cont = FotF_CustomKeywordDictionary[string];
            if (typeof cont === 'object' && cont.hasOwnProperty('keyword') && obj.getCustomKeyword() === cont.keyword) {
                if (typeof cont.keyword === 'function' && cont.keyword() === obj.getCustomKeyword()) {
                    return cont;
                } else if (typeof cont.keyword === 'string' && cont.keyword === obj.getCustomKeyword()) {
                    return cont;
                }
            }
        }

        return undefined;
    },

    checkObject: function (obj, string, objectType) {
        var dict = this.getDictionaryByType(objectType);
        var cont = dict[string];

        if (typeof cont !== 'undefined') {
            return cont;
        }

        if (objectType === ObjectType.SKILL) {
            cont = this.checkCustomKeyword(obj, dict);
        }

        return cont;
    },

    getSentenceCount: function (obj, objectType) {
        var n = 0;
        var custom = obj.custom;
        var cfg = FotF_CusparaRenderSettings;

        for (string in custom) {
            var cont = this.checkObject(obj, string, objectType);

            if (typeof cont !== 'undefined') {
                var customSpacing = this.getCustomSpacing(cont, obj);
                if (typeof customSpacing === 'number') {
                    n += customSpacing;
                } else {
                    n++;
                }
            }
        }

        if (objectType === ObjectType.SKILL) {
            var cont = this.checkKeywordDictionary(obj);

            if (typeof cont !== 'undefined') {
                var customSpacing = this.getCustomSpacing(cont, obj);
                if (typeof customSpacing === 'number') {
                    n += customSpacing;
                } else {
                    n++;
                }
            }
        }

        if (cfg.drawDescriptionInInfoWindows && (objectType === ObjectType.SKILL || objectType === ObjectType.ITEM || objectType === ObjectType.WEAPON || objectType === ObjectType.STATE)) {
            var font = root.getBaseData().getFontList().getDataFromId(cfg.descriptionFontId);
            var lines = Math.ceil(TextRenderer.getTextWidth(obj.getDescription(), font) / this.getMaxDescriptionWidth(objectType));
            n += lines;
        }

        return n;
    },

    getTitleHeight: function (spacing) {
        var cfg = FotF_CusparaRenderSettings;
        var height = GraphicsFormat.ICON_HEIGHT + cfg.bigIconSpacingY;

        return Math.ceil((height / cfg.lineSpacingY) * spacing);
    },

    getMaxDescriptionWidth: function (objectType) {
        if (objectType === ObjectType.SKILL) {
            var extra = 0;
            if (typeof FotF_UnitMenuOverhaulSettings === 'object') {
                extra += GraphicsFormat.ICON_WIDTH + FotF_UnitMenuOverhaulSettings.infoWindowIconSpacingX;
            }
            return SkillInfoWindow.getWindowWidth() - (2 * SkillInfoWindow.getWindowXPadding() + extra);
        } else if (objectType === ObjectType.ITEM || objectType === ObjectType.WEAPON) {
            return ItemInfoWindow.getWindowWidth() - 2 * ItemInfoWindow.getWindowXPadding();
        } else if (objectType === ObjectType.STATE && typeof FotF_StateInfoWindow === 'object') {
            return FotF_UnitMenuOverhaulSettings.infoWindowWidth - 2 * FotF_StateInfoWindow.getWindowXPadding();
        }

        return 0;
    },

    getDescription: function (cont, obj) {
        if (cont.hasOwnProperty('text')) {
            if (typeof cont.text === 'string') {
                return cont.text;
            } else if (typeof cont.text === 'function') {
                return cont.text(cont, obj);
            }
        }

        return null;
    },

    getDescription2: function (cont, obj) {
        if (cont.hasOwnProperty('text')) {
            if (typeof cont.text2 === 'string') {
                return cont.text2;
            } else if (typeof cont.text2 === 'function') {
                return cont.text2(cont, obj);
            }
        }

        return null;
    },

    getValue: function (cont, obj) {
        if (cont.hasOwnProperty('func')) {
            return cont.func(cont, obj);
        }

        return null;
    },

    getDrawFunction: function (cont) {
        if (cont.hasOwnProperty('draw')) {
            return cont.draw;
        }

        return null;
    },

    getCustomSpacing: function (cont, obj) {
        if (cont.hasOwnProperty('getSpacing')) {
            return cont.getSpacing(cont, obj);
        }

        return 1;
    }
};

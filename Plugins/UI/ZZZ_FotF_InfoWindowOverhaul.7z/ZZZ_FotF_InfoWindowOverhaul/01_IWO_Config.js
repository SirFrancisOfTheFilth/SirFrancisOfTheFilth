/*--------------------------------------------------------------------------
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        MORE. INFO. IN. INFOWINDOWS.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This plugin does several things:

-   First of all it overwrites basically the entirety of all info windows.
    This includes item, skill and terrain info windows. Everything is done
    via a central renderer object and all settings can be done in this file.

-   The other main function of this plugin is the drawing of information
    about custom parameters on weapons, items, skills, terrain (+ possibly
    states if you integrate this plugin into your custom state info windows).
    Drawing information for custom parameters is stored in the dictionary
    file, which will frequently be updated to support all of my future
    plugins, as well as all those of other authors I use personally. Of
    course if you want to add some yourself, feel free to do so, and feel
    even more free to send them to me so I can update the dictionary for
    everyone. I will also be taking requests to incorporate custom parameters
    into the dictionary.

-   Some smaller quality of life changes regarding the info windows like:
    > Adding recovery to the terrain info window
    > Revamping how invocation rates are shown
    > Regrouping/improving some standard item descriptions
    > Drawing object descriptions into the info window itself
    > Drawing damage/heal numbers in different colors depending on damage type
    > Hiding the bottom description window, if so desired

_____________________________________________________________________________
						         Setup
_____________________________________________________________________________

First of all, make sure you have the newest version of the config file, the
functionality file and the cuspara dictionary. Now it's probably best to check
the settings section in this file and adjust it to your liking.
Especially important is how big you extend the width of the info windows, as
this plugin is built for large info windows (around +200 px width, depending
on the font).

_____________________________________________________________________________
                        Adding unsupported plugins
                            (Basic method)
_____________________________________________________________________________

To add support for not yet supported plugins, you have to create an object in
the dictionary file. It's important to create it under the right category
(multiple if necessary). The simplest form of one such object looks like this:

    mutualState: {
        text: 'Inflicts',
        func: function (cont, obj) {
            return root.getBaseData().getStateList().getDataFromId(obj.custom.mutualState).getName();
        },
        text2: 'on user when attacking'
    }

Loooking at this example, we can see the name of the object "mutualState",
which has to be identical to the custom parameter/custom keyword.

The first thing to be drawn is the first text. This can either be plain text
(a string) or a function returning a string.

After this, the func value is drawn. This is used to get either a numerical
value (for example the amount of damage) or text (here the name of a state).
This is achieved through the func function returning that value. cont is the
"container" object (in this case mutualState) and obj is the object holding
the custom parameter (in this case a skill).

Lastly, text2 works just like text, but is drawn after the value from func.

So this custom parameter would be rendered as

    Inflicts (state name) on user when attacking

text, func and text2 are all optional, you can omit any of them.
All of it will be rendered on a single line, spacings are done automatically.

_____________________________________________________________________________
                        Adding unsupported plugins
                            (Custom keywords)
_____________________________________________________________________________

Some custom keywords (like "Special-Recoil", which is already supported)
contain characters that make them unsuitable as javascript object names or
have varying keyword names.
This includes names starting with numbers, containing certain special
characters like "-", ".", ",", ";", ":" and some others like brackets.

To support these as well, you can add an entry to the custom keyword
dictionary. The format is the same as with all other custom parameters, but
the object name (mutualState in the previous example) can be anything, as
long as it contains no banned characters and is not a duplicate of something
already existing in the dictionary. Now just add another function to the
entry named "keyword" and let it return the custom keyword as a string:

extendedPursuit: {
    keyword: function () {
        return FotF_ExtendedPursuitSettings.customKeyword;
    },
    text: 'Allow up to',
    func: function (cont, obj) {
        FotF_ExtendedPursuitSettings.pursuitMultipliers;
    },
    text2: 'consecutive attacks'
}

In this example, the keyword is set in the corresponding plugin's settings
and is accessed through it's settings object. If that is not the case for
you or you don't care, just return a string.

_____________________________________________________________________________
                        Adding unsupported plugins
                         (Advanced functionality)
_____________________________________________________________________________

If the basic drawing methods are not flexible enough for you, you can also
define your own draw function like this:

    ammoArray: {
        draw: function (x, y, cont, obj) {
            var i;
            var arr = obj.custom.ammoArray;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, 'Ammo');
            x += FotF_CusparaRenderSettings.itemStatSpacingX;

            for (i = 0; i < arr.length; i++) {
                var item = root.getBaseData().getItemList().getDataFromId(arr[i]);
                renderer.drawName(x, y, item.getName());
                y += FotF_CusparaRenderSettings.lineSpacingY;
            }
        },

        getSpacing: function (cont, obj) {
            return obj.custom.ammoArray.length;
        }
    }

As you can see, the draw function already comes prepared with coordinates.
I prepared special drawing functions under FotF_CusparaRenderer to preserve
a coherent style. These are:

    - drawTitle(x, y, text)
        It draws a title text, whoa! You can do a different font and size I guess

    - drawText(x, y, text)
        It just draws plain text

    - drawName(x, y, text)
        To draw names like skill/state/unit names

    - drawNumber(x, y, value, obj, index);
        Draws numbers (as text). value needs to be a number (can be decimal).
        obj is the object from which the number comes, for example a weapon,
        whose attack is drawn.index is a color index that determines the
        number's color (0 = default, 1 = physical dmg, 2 = magic dmg,
        3 = true dmg, 4 = healing). If obj is a weapon, it will automatically
        use the right color for the damage type. If obj is null and index
        isn't, the index determines the color. If both are null, it's default.

    - drawSign(x, y, text)
        To draw signs like +, -, *, /, %, ...

    - drawIcon(x, y, icon)
        draws icons (usually in conjunction with drawTitle)

    - drawDescription(x, y, text)
        draws Description text, should be done automatically

    - drawInvocation(x, y, obj, value, type)
        draws state/skill/... invocations. obj is the state/skill/etc., value
        is the invocation value (percentage) and type id the invocation type
        (absolute, HP, parameter, ...)

To keep the style coherent, all drawing functions return their text length.
This way you can simply keep increasing x until you need a line break.
Line breaks are done with the value from the config (lineSpacingY).
There is also the config item "itemStatSpacingX", which can be used for
consistent horizontal spacings.

Lastly, the amount of lines the custom drawing functions needs has to be
set in getSpacing. If you omit it, it will default to a single line.

_____________________________________________________________________________
						Adding state info windows
_____________________________________________________________________________

This plugin does not add state info windows, but if your UI has those, you
can, with relative ease, integrate this plugin into your UI plugin and show
custom parameters in your state info windows. The dictionary for this is
already included.

You can look at how best to do the drawing function and dynamic window height
expansion in the "Functionality" file's drawing functions for the other info
windows.

The state cuspara dictionary allows for the unit to be used as an argument in
the draw function, which is unique to state info windows. You can leave it
undefined if not needed.

_____________________________________________________________________________
						    Compatibility
_____________________________________________________________________________

Overwritten functions:

    - ALL ItemSentence objects
    - ALL ItemInfo objects
    - UnitMenuScreen.drawScreenBottomText (only if disableBottomDescriptionWindow is true)
    - ItemInfoRenderer.getSpaceY
    - ItemInfoRenderer.drawList
    - ItemInfoRenderer.drawDoping
    - ItemInfoRenderer.drawState
    - BaseItemInfo.drawRange
    - BaseMapParts.getIntervalY
    - BaseItemSentence._getMiddleSpace
    - ItemInfoWindow._configureWeapon
    - ItemInfoWindow._configureItem
    - AggregationViewer.drawAggregationViewer
    - AggregationViewer._drawList
    - SkillInfoWindow.drawWindowContent
    - MapParts.Terrain._drawContent
    - MapParts.Terrain._getWindowHeight
    - MapParts.Terrain._getPartsCount

Aliased functions:

    - SkillInfoWindow.getWindowWidth
    - SkillInfoWindow.getWindowHeight
    - SkillInfoWindow.setSkillInfoData
    - MapParts.Terrain._getWindowWidth
    - ItemInfoWindow.setInfoItem
_____________________________________________________________________________
								 EPILOGUE
_____________________________________________________________________________

Once again, this is intended as somewhat of a public library of custom
parameter rendering functions. If you extend this dictionary, please consider
sharing your work with me, so I can update this dictionary file for all to use.

If you have any questions about this plugin or want me to include a plugin in
the dictionary, feel free to reach out to me over the SRPG Studio University
Discord server @SirFrancisoftheFilth
  
Original Plugin Author:
Francis of the Filth

2025/10/22
Released

--------------------------------------------------------------------------*/

/*-------------------------------------------------------------
                           SETTINGS
-------------------------------------------------------------*/
var FotF_CusparaRenderSettings = {
    //General settings
    lineSpacingY: 22, //Controls how tall line breaks are
    bigIconSpacingX: 8, //Horizontal spacing between icon and title text
    bigIconSpacingY: 8, //Vertical spacing between icon and title text
    extraSkillInfoSpacingX: 214, //Horizontal expansion for skill info window
    extraTerrainInfoSpacingX: 200, //Horizontal expansion for skill terrain window
    extraItemInfoSpacingX: 180, //Horizontal expansion for item info window
    drawDescriptionInInfoWindows: true, //Whether to draw an object's description in it's info window. Recommended to disable bottom description window if true.
    disableWlvInItemInfo: true, //Hide Wlv in item info (if you use the stat for something else)
    disableBottomDescriptionWindow: true, //Hides bottom description window, good with drawDescriptionInInfoWindows
    terrainRecoveryString: 'Heal', //Text to draw for terrain auto recovery

    //Title
    titleFontId: 0,
    titleFontSpacing: 5,
    titleColor: 0xffffff,
    titleAlpha: 255,
    titleOffsetY: 4,

    //Text
    stringFontId: 0,
    stringFontSpacing: 4,
    stringColor: 0xffffff,
    stringAlpha: 255,

    //Names (like items, states, ...)
    nameFontId: 0,
    nameFontSpacing: 4,
    nameColor: 0x40bfff,
    nameAlpha: 255,

    //Numbers (damage, healing, ...)
    numberFontId: 0,
    numberFontSpacing: 4,
    numberColorDefault: 0xe3c405,
    numberColorPhysical: 0x992b00,
    numberColorMagic: 0x48bdbd,
    numberColorTrue: 0xf01acb,
    numberColorHealing: 0x33ab3d,
    numberAlpha: 255,

    //Signs (+, -, *, /, %, ...)
    signFontId: 0,
    signFontSpacing: 4,
    signColor: 0x40bfff,
    signAlpha: 255,

    //Descriptions
    descriptionFontId: 0,
    descriptionFontSpacing: 4,
    descriptionColor: 0x8c8c8c,
    descriptionAlpha: 255,

    //Icons
    iconWidth: 16,
    iconHeight: 16,
    iconOffsetY: 2,
    iconSpacingX: 4,

    //Item Info
    itemStatSpacingX: 16 //Used for weapon stat spacing among other things
};

/*--------------------------------------------------------------------------
_____________________________________________________________________________
					SUPPORTED PLUGINS AND THEIR CUSTOM PARAMETERS
_____________________________________________________________________________

PLUGIN                              CUSTOM PARAMETER / KEYWORD                                  SUPPORTED OBJECTS                                   NOTES

FotF_AllowItemAsWeapon              allowAsWeapon                                               items
FotF_MultiplicativeParamBonus       paramFactor, paramFactorRegen                               weapons, items, skills, states, terrain             uses own render functions
FotF_CustomBrokenWeapon             customBreakWeapon, customBreakItem                          weapons, items
FotF_NoAttackAfterMove              beforeMov                                                   weapons, items                                      items only with FotF_AllowItemAsWeapon
FotF_PCMath_Elements                element, elementBoost, elementResist                        weapons, items, skills, states, terrain             uses own renderer, compatible with FotF_PCMath_AOE
FotF_MutualState                    mutualState                                                 skills
ThornsRecoil by Cube                recoil, reflect                                             skills
live-to-serve by Goinza             LiveToServe                                                 skills
AddWeaponTypeSkill by Cube          addWeaponType                                               skills
FotF_DynamicState                   dynamicState                                                states
FotF_DanceFever                     danceFever                                                  states
FotF_DrunkState                     booze                                                       states
FotF_SadoMaso                       sadism, masochism                                           states
FotF_SpreadingState                 spreadState                                                 states
Taunt by MarkyJoe                   isTaunt                                                     states
CountDownState by MarkyJoe          exitDamage, exitState, isAutoEventCheck                     states                                              added cusparas for event description
FotF_ThirdLayer                     StealthCL                                                   terrain
FotF_FurnitureWrappers              moveable                                                    terrain
FotF_ExtendedPursuit                ExtendedPursuit                                             skills
Clumsy and Hard Armor by Cube       Clumsy, Hard Armor                                          skills
FotF_PCMath_AOE                     aoe                                                         items                                               supported natively, no entry needed
--------------------------------------------------------------------------*/

/*-------------------------------------------------------------
                        ITEM DICTIONARY
-------------------------------------------------------------*/
var FotF_ItemCusparaDictionary = {
    //FotF_AllowItemAsWeapon by Francis of the Filth
    allowAsWeapon: {
        text: 'Useable as weapon'
    },

    //FotF_MultiplicativeParamBonus by Francis of the Filth
    paramFactor: {
        draw: function (x, y, cont, obj) {
            var bonusCount = FotF_ParamFactorRenderer.getBonusCount(obj);

            if (bonusCount !== 0) {
                FotF_ParamFactorRenderer.drawParamBonus(x, y, obj, FotF_CusparaRenderSettings.lineSpacingY);
            }
        },
        getSpacing: function (cont, obj) {
            return FotF_ParamFactorRenderer.getParamSpacing(obj, 0, 1);
        }
    },

    //FotF_CustomBrokenWeapon by Francis of the Filth
    customBreakWeapon: {
        text: 'Depletes into',
        func: function (cont, obj) {
            return root.getBaseData().getWeaponList().getDataFromId(obj.custom.customBreakWeapon).getName();
        }
    },

    //FotF_CustomBrokenWeapon by Francis of the Filth
    customBreakItem: {
        text: 'Depletes into',
        func: function (cont, obj) {
            return root.getBaseData().getWeaponList().getDataFromId(obj.custom.customBreakItem).getName();
        }
    },

    //FotF_No AttackAfterMove by Francis of the Filth
    beforeMov: {
        text: 'Cannot attack after moving'
    }
};

/*-------------------------------------------------------------
                        WEAPON DICTIONARY
-------------------------------------------------------------*/
var FotF_WeaponCusparaDictionary = {
    //FotF_MultiplicativeParamBonus by Francis of the Filth
    paramFactor: {
        draw: function (x, y, cont, obj) {
            var bonusCount = FotF_ParamFactorRenderer.getBonusCount(obj);

            if (bonusCount !== 0) {
                FotF_ParamFactorRenderer.drawParamBonus(x, y, obj, FotF_CusparaRenderSettings.lineSpacingY);
            }
        },
        getSpacing: function (cont, obj) {
            return FotF_ParamFactorRenderer.getParamSpacing(obj, 0, 1);
        }
    },

    //FotF_CustomBrokenWeapon by Francis of the Filth
    customBreakWeapon: {
        text: 'Depletes into',
        func: function (cont, obj) {
            return root.getBaseData().getWeaponList().getDataFromId(obj.custom.customBreakWeapon).getName();
        }
    },

    //FotF_CustomBrokenWeapon by Francis of the Filth
    customBreakItem: {
        text: 'Depletes into',
        func: function (cont, obj) {
            return root.getBaseData().getWeaponList().getDataFromId(obj.custom.customBreakItem).getName();
        }
    },

    //FotF_NoAttackAfterMove by Francis of the Filth
    beforeMov: {
        text: 'Cannot attack after moving'
    },

    //Elements by PCMath, modified by Francis of the Filth
    element: {
        draw: function (x, y, cont, obj) {
            FotF_ElementRenderer.drawElement(x, y, obj);
        },

        getSpacing: function (cont, obj) {
            return 1;
        }
    },

    //Custom gun plugin by me
    burstMax: {
        draw: function (x, y, cont, obj) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, FotF_BurstStrings.maxBurst);
            x += cfg.itemStatSpacingX;
            x += renderer.drawNumber(x, y, 1, null, null);
            x += renderer.drawSign(x, y, '-');
            renderer.drawNumber(x, y, obj.custom.burstMax, null, null);
        }
    },

    //Custom gun plugin by me
    burstRecoil: {
        draw: function (x, y, cont, obj) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, FotF_BurstStrings.recoil);
            x += cfg.itemStatSpacingX;
            renderer.drawNumber(x, y, obj.custom.burstRecoil, null, null);
        }
    },

    //Custom gun plugin by me
    multiShot: {
        text: function (cont, obj) {
            return FotF_BurstStrings.multiShot;
        },

        func: function (cont, obj) {
            return obj.custom.multiShot;
        }
    },

    //Custom gun plugin by me
    armorPen: {
        draw: function (x, y, cont, obj) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, FotF_BurstStrings.armorPen);
            x += cfg.itemStatSpacingX;
            x += renderer.drawNumber(x, y, obj.custom.armorPen * 100, null, null);
            renderer.drawSign(x, y, '%');
        }
    },

    //Custom gun plugin by me
    falloffDistance: {
        draw: function (x, y, cont, obj) {
            var text;
            var renderer = FotF_CusparaRenderer;
            var cfg = FotF_CusparaRenderSettings;
            var distance = obj.custom.falloffDistance;
            var factor = obj.custom.falloffFactor;

            if (factor === null) {
                factor = 1;
            }

            if (distance !== null) {
                text = FotF_BurstStrings.falloff;
                x += renderer.drawText(x, y, text);
                x += cfg.itemStatSpacingX;
                x += renderer.drawNumber(x, y, distance, null, null) - cfg.numberFontSpacing;
                x += renderer.drawSign(x, y, '+');
                x += renderer.drawSign(x, y, '/');
                x += renderer.drawNumber(x, y, factor, null, null);
            }
        }
    },

    //Custom gun plugin by me
    ammoArray: {
        draw: function (x, y, cont, obj) {
            var i;
            var arr = obj.custom.ammoArray;
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, 'Ammo');
            x += FotF_CusparaRenderSettings.itemStatSpacingX;

            for (i = 0; i < arr.length; i++) {
                var item = root.getBaseData().getItemList().getDataFromId(arr[i]);
                renderer.drawName(x, y, item.getName());
                y += FotF_CusparaRenderSettings.lineSpacingY;
            }
        },

        getSpacing: function (cont, obj) {
            return obj.custom.ammoArray.length;
        }
    }
};

/*-------------------------------------------------------------
                        SKILL DICTIONARY
-------------------------------------------------------------*/
var FotF_SkillCusparaDictionary = {
    //FotF_MutualState by Francis of the Filth
    mutualState: {
        text: 'Inflicts',
        func: function (cont, obj) {
            return root.getBaseData().getStateList().getDataFromId(obj.custom.mutualState).getName();
        },
        text2: 'on user when attacking'
    },

    //FotF_MultiplicativeParamBonus by Francis of the Filth
    paramFactor: {
        draw: function (x, y, cont, obj) {
            var bonusCount = FotF_ParamFactorRenderer.getBonusCount(obj);

            if (bonusCount !== 0) {
                if (obj.getSkillType() === SkillType.SUPPORT) {
                    FotF_ParamFactorRenderer.drawAbilityBonus(x, y, obj, FotF_CusparaRenderSettings.lineSpacingY);
                } else {
                    FotF_ParamFactorRenderer.drawParamBonus(x, y, obj, FotF_CusparaRenderSettings.lineSpacingY);
                }
            }
        },
        getSpacing: function (cont, obj) {
            return FotF_ParamFactorRenderer.getParamSpacing(obj, 0, 1);
        }
    },

    //FotF_MultiplicativeParamBonus by Francis of the Filth
    paramFactorRegen: {
        draw: function (x, y, cont, obj) {
            FotF_ParamFactorRenderer.drawRecovery(x, y, obj);
        },
        getSpacing: function (cont, obj) {
            return FotF_ParamFactorRenderer.getRecoverySpacing(obj, 0, 1);
        }
    },

    //ThornsRecoil by Cube
    recoil: {
        text: "User's attacks also hurt themselves"
    },

    //ThornsRecoil by Cube
    reflect: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, 'Reflects');
            x += renderer.drawNumber(x, y, obj.custom.reflectRate, null, null);
            x += renderer.drawSign(x, y, '%');
            renderer.drawText(x, y, 'of damage back to attackers');
        }
    },

    //Elements by PCMath, modified by Francis of the Filth
    elementBoost: {
        draw: function (x, y, cont, obj) {
            FotF_ElementRenderer.drawFactorBoost(x, y, obj);
        },

        getSpacing: function (cont, obj) {
            return FotF_ElementRenderer.getSpacingBoost(obj);
        }
    },

    //Elements by PCMath, modified by Francis of the Filth
    elementResist: {
        draw: function (x, y, cont, obj) {
            FotF_ElementRenderer.drawFactorResist(x, y, obj);
        },

        getSpacing: function (cont, obj) {
            return FotF_ElementRenderer.getSpacingResist(obj);
        }
    },

    //live-to-serve by Goinza
    LiveToServe: {
        text: 'Receive the same healing when healing allies with an item'
    },

    //AddWeaponTypeSkill by Cube
    addWeaponType: {
        text: 'Can use',
        func: function (cont, obj) {
            var type = root.getBaseData().getWeaponTypeList(obj.custom.weaponCategoryTypeIndex).getDataFromId(obj.custom.weaponTypeID);
            return type.getName();
        }
    },

    //Custom gun plugin by me
    maxBurstBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.maxBurstBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, 'Maximum ' + FotF_BurstStrings.maxBurst);
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
        }
    },

    //Custom gun plugin by me
    recoilBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.recoilBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, FotF_BurstStrings.recoil);
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
        }
    },

    //Custom gun plugin by me
    multiShotBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.multiShotBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, FotF_BurstStrings.multiShot);
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
        }
    },

    //Custom gun plugin by me
    armorPenBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.armorPenBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, FotF_BurstStrings.armorPen);
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
        }
    },

    //Custom gun plugin by me
    falloffDistanceBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.falloffDistanceBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, 'Falloff distance');
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
        }
    },

    //Custom gun plugin by me
    falloffFactorBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.falloffFactorBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, 'Damage falloff');
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
        }
    }
};

/*-------------------------------------------------------------
                        STATE DICTIONARY
These are not supported in vanilla SRPGS. I leave them here
nonetheless, because if you have state info windows from custom
UI and know what you're doing, you can integrate them into it.
How best to do that can be seen in the ItemInfoWindow and
SkillInfoWindow drawing function overrides of this plugin.
The func parameter also takes the unit as a third parameter in
my case, remove it if your code doesn't support this.
-------------------------------------------------------------*/
var FotF_StateCusparaDictionary = {
    //FotF_DynamicState by Francis of the Filth
    dynamicState: {
        draw: function (x, y, cont, obj, unit) {
            var renderer = FotF_CusparaRenderer;

            x += renderer.drawText(x, y, 'Stacks');
            x += renderer.drawNumber(x, y, FotF_DynamicStateControl.getLevel(obj), null, null);
            x += renderer.drawSign(x, y, '/');
            x += renderer.drawNumber(x, y, FotF_DynamicStateControl.getMaxLevel(obj), null, null);
        },
        text: 'Stacks',
        func: function (cont, obj, unit) {
            return FotF_DynamicStateControl.getLevel(obj);
        }
    },

    //FotF_MultiplicativeParamBonus by Francis of the Filth
    paramFactor: {
        draw: function (x, y, cont, obj) {
            var bonusCount = FotF_ParamFactorRenderer.getBonusCount(obj);

            if (bonusCount !== 0) {
                FotF_ParamFactorRenderer.drawParamBonus(x, y, obj, FotF_CusparaRenderSettings.lineSpacingY);
            }
        },
        getSpacing: function (cont, obj) {
            return FotF_ParamFactorRenderer.getParamSpacing(obj, 0, 1);
        }
    },

    //FotF_MultiplicativeParamBonus by Francis of the Filth
    paramFactorRegen: {
        draw: function (x, y, cont, obj) {
            FotF_ParamFactorRenderer.drawRecovery(x, y, obj);
        },
        getSpacing: function (cont, obj) {
            return FotF_ParamFactorRenderer.getRecoverySpacing(obj, 0, 1);
        }
    },

    //FotF_DanceFever by Francis of the Filth
    danceFever: {
        text: 'Causes uncontrollable dancing'
    },

    //FotF_DrunkState by Francis of the Filth
    booze: {
        text: 'Might cause swaying and tripping'
    },

    //FotF_SadoMaso by Francis of the Filth
    sadism: {
        text: 'Hitting an enemy grants',
        func: function (cont, obj, unit) {
            return obj.custom.sadism.value;
        },
        text2: function (cont, obj) {
            return ParamGroup.getParameterName(obj.custom.sadism.stat) + ' (max. ' + obj.custom.sadism.max + ')';
        }
    },

    //FotF_SadoMaso by Francis of the Filth
    masochism: {
        text: 'Hitting an enemy grants',
        func: function (cont, obj, unit) {
            return obj.custom.masochism.value;
        },
        text2: function (cont, obj) {
            return ParamGroup.getParameterName(obj.custom.masochism.stat) + ' (max. ' + obj.custom.masochism.max + ')';
        }
    },

    //FotF_SpreadingState by Francis of the Filth
    spreadState: {
        draw: function (x, y, cont, obj) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;

            var custom = obj.custom.spreadState;
            var value = custom.chance;
            var range = custom.range;
            var savedX = x;
            var text1 = 'chance to spread to ';

            if (custom.armyFilter === UnitFilterFlag.PLAYER || custom.armyFilter === UnitFilterFlag.ALLY) {
                text1 += 'allies in';
            } else if (custom.armyFilter === UnitFilterFlag.ENEMY) {
                text1 += 'enemies in';
            } else if (custom.armyFilter === UnitFilterFlag.OPTIONAL) {
                text1 += 'units in';
            } else {
                return;
            }

            var text2 = 'range';

            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
            x += renderer.drawText(x, y, text1);
            x += renderer.drawNumber(x, y, range, null, null);
            x += renderer.drawText(x, y, text2);

            if (custom.requiresSkill) {
                var text3 = 'Requires skill';
                x = savedX;
                y += cfg.lineSpacingY;
                x += renderer.drawText(x, y, text3);
            }
        },

        getSpacing: function (cont, obj) {
            return obj.custom.spreadState.requiresSkill ? 2 : 1;
        }
    },

    //Taunt by MarkyJoe
    isTaunt: {
        text: 'Taunted by',
        func: function (cont, obj, unit) {
            if (typeof unit.custom.tauntTarget === 'object') {
                return unit.custom.tauntTarget;
            }

            return 'no one';
        }
    },

    //CountDownState by MarkyJoe
    exitState: {
        text: 'Inflicts',
        func: function (cont, obj, unit) {
            var stateId = obj.custom.exitState;

            if (typeof stateId === 'number') {
                var state = root.getBaseData().getStateList().getDataFromId(obj.custom.exitState);
            } else if (typeof stateId === 'function') {
                var state = root.getBaseData().getStateList().getDataFromId(obj.custom.exitState(unit, obj));
            }

            if (typeof state === 'object') {
                return state.getName();
            }

            return '';
        },
        text2: 'after expiring'
    },

    //CountDownState by MarkyJoe
    exitDamage: {
        text: 'Deals',
        func: function (cont, obj, unit) {
            var value = obj.custom.exitDamage;

            if (typeof value === 'number') {
                return value;
            } else if (typeof value === 'function') {
                return value(unit, obj);
            }

            return null;
        },
        text2: 'damage after expiring'
    },

    //CountDownState by MarkyJoe
    isAutoEventCheck: {
        text: function (cont, obj) {
            if (typeof obj.custom.autoEventText === 'string') {
                return obj.custom.autoEventText;
            } else if (typeof obj.custom.autoEventText === 'function') {
                return obj.custom.autoEventText(obj);
            }

            return null;
        },

        text2: function (cont, obj) {
            if (typeof obj.custom.autoEventText2 === 'string') {
                return obj.custom.autoEventText2;
            } else if (typeof obj.custom.autoEventText2 === 'function') {
                return obj.custom.autoEventText2(obj);
            }

            return null;
        }
    },

    //Elements by PCMath, modified by Francis of the Filth
    element: {
        draw: function (x, y, cont, obj) {
            FotF_ElementRenderer.drawElement(x, y, obj);
        },

        getSpacing: function (cont, obj) {
            return 1;
        }
    },

    //Elements by PCMath, modified by Francis of the Filth
    elementBoost: {
        draw: function (x, y, cont, obj) {
            FotF_ElementRenderer.drawFactorBoost(x, y, obj);
        },

        getSpacing: function (cont, obj) {
            return FotF_ElementRenderer.getSpacingBoost(obj);
        }
    },

    //Elements by PCMath, modified by Francis of the Filth
    elementResist: {
        draw: function (x, y, cont, obj) {
            FotF_ElementRenderer.drawFactorResist(x, y, obj);
        },

        getSpacing: function (cont, obj) {
            return FotF_ElementRenderer.getSpacingResist(obj);
        }
    },

    //Custom gun plugin by me
    maxBurstBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.maxBurstBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, 'Maximum ' + FotF_BurstStrings.maxBurst);
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
        }
    },

    //Custom gun plugin by me
    recoilBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.recoilBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, FotF_BurstStrings.recoil);
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
        }
    },

    //Custom gun plugin by me
    multiShotBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.multiShotBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, FotF_BurstStrings.multiShot);
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
        }
    },

    //Custom gun plugin by me
    armorPenBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.armorPenBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, FotF_BurstStrings.armorPen);
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
        }
    },

    //Custom gun plugin by me
    falloffDistanceBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.falloffDistanceBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, 'Falloff distance');
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
        }
    },

    //Custom gun plugin by me
    falloffFactorBoost: {
        draw: function (x, y, cont, obj) {
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.falloffFactorBoost;

            if (value >= 0) {
                var sign = '+';
            } else {
                var sign = '-';
                value *= -1;
            }

            x += renderer.drawText(x, y, 'Damage falloff');
            x += renderer.drawSign(x, y, sign);
            x += renderer.drawNumber(x, y, value, null, null);
            x += renderer.drawSign(x, y, '%');
        }
    }
};

/*-------------------------------------------------------------
                        TERRAIN DICTIONARY
-------------------------------------------------------------*/
var FotF_TerrainCusparaDictionary = {
    //FotF_ThirdLayer by Francis of the Filth
    StealthCL: {
        text: 'Hides units'
    },

    //FotF_MultiplicativeParamBonus by Francis of the Filth
    paramFactor: {
        draw: function (x, y, cont, obj) {
            var bonusCount = FotF_ParamFactorRenderer.getBonusCount(obj);

            if (bonusCount !== 0) {
                FotF_ParamFactorRenderer.drawTerrainBonus(x, y, obj, FotF_CusparaRenderSettings.lineSpacingY);
            }
        },
        getSpacing: function (cont, obj) {
            return FotF_ParamFactorRenderer.getParamSpacing(obj, 0, 1);
        }
    },

    //FotF_MultiplicativeParamBonus by Francis of the Filth
    paramFactorRegen: {
        draw: function (x, y, cont, obj) {
            FotF_ParamFactorRenderer.drawRecovery(x, y, obj);
        },
        getSpacing: function (cont, obj) {
            return FotF_ParamFactorRenderer.getRecoverySpacing(obj, 0, 1);
        }
    },

    //FotF_FurnitureWrapper by Francis of the Filth
    moveable: {
        text: 'Can be picked up'
    },

    //Elements by PCMath, modified by Francis of the Filth
    elementBoost: {
        draw: function (x, y, cont, obj) {
            FotF_ElementRenderer.drawFactorBoost(x, y, obj);
        },

        getSpacing: function (cont, obj) {
            return FotF_ElementRenderer.getSpacingBoost(obj);
        }
    },

    //Elements by PCMath, modified by Francis of the Filth
    elementResist: {
        draw: function (x, y, cont, obj) {
            FotF_ElementRenderer.drawFactorResist(x, y, obj);
        },

        getSpacing: function (cont, obj) {
            return FotF_ElementRenderer.getSpacingResist(obj);
        }
    }
};

/*-------------------------------------------------------------
                    CUSTOM KEYWORD DICTIONARY
For custom keywords that can't be used as object names due to
javascript syntax restrictions, like ones using "-"" or starting
with numbers. The name of the object itself can be chosen freely
as long as there are no duplicates, the important part is the
"keyword" property, which has to contain the exact custom keyword
-------------------------------------------------------------*/

var FotF_CustomKeywordDictionary = {
    //special-recoil by MarkyJoe
    specialRecoil: {
        keyword: 'Special-Recoil',
        draw: function (x, y, cont, obj) {
            var cfg = FotF_CusparaRenderSettings;
            var renderer = FotF_CusparaRenderer;
            var value = obj.custom.value;
            var stateId = obj.custom.stateId;
            var onKill = obj.custom.onKill;
            var numberColor = 3;
            var savedX = x;
            var text1 = '';
            var text2 = '';
            var text3 = '';
            var text4 = '';
            var text5 = '';

            if (onKill) {
                text5 += 'when killing an enemy';
            } else {
                text5 += 'when hitting an enemy';
            }

            if (typeof value === 'number' && value !== 0 && typeof stateId === 'number') {
                var state = root.getBaseData().getStateList().getDataFromId(stateId);

                if (value > 0) {
                    text1 += 'Deals';
                    text2 += 'damage to and inflicts the attacker';
                } else {
                    text1 += 'Heals attacker by';
                    text2 += 'HP and inflicts them';
                    numberColor = 4;
                }

                text3 += 'with';
                text4 += state.getName();

                x += renderer.drawText(x, y, text1);
                x += renderer.drawNumber(x, y, value, null, numberColor);
                x += renderer.drawText(x, y, text2);

                x = savedX;
                y += cfg.lineSpacingY;

                x += renderer.drawText(x, y, text3);
                x += renderer.drawName(x, y, text4);
                x += renderer.drawText(x, y, text5);
            } else if (typeof value === 'number' && value !== 0) {
                if (value > 0) {
                    text1 += 'Deals';
                    text2 += 'damage to the attacker';
                } else {
                    text1 += 'Heals attacker by';
                    text2 += 'HP';
                    numberColor = 4;
                }

                x += renderer.drawText(x, y, text1);
                x += renderer.drawNumber(x, y, value, null, numberColor);
                x += renderer.drawText(x, y, text2);

                x = savedX;
                y += cfg.lineSpacingY;

                x += renderer.drawText(x, y, text5);
            } else if (typeof stateId === 'number') {
                var state = root.getBaseData().getStateList().getDataFromId(stateId);

                text1 += 'Inflicts the attacker with';
                text2 += state.getName();

                x += renderer.drawText(x, y, text1);
                x += renderer.drawName(x, y, text2);

                x = savedX;
                y += cfg.lineSpacingY;

                x += renderer.drawText(x, y, text5);
            }
        },
        getSpacing: function (cont, obj) {
            return 2;
        }
    },

    extendedPursuit: {
        keyword: function () {
            return FotF_ExtendedPursuitSettings.customKeyword;
        },
        text: 'Allow up to',
        func: function (cont, obj) {
            FotF_ExtendedPursuitSettings.pursuitMultipliers;
        },
        text2: 'consecutive attacks'
    },

    //Clumsy and Hard Armor by Cube
    clumsy: {
        keyword: 'Clumsy',
        text: 'Attacks use up',
        func: function (cont, obj) {
            return obj.custom.decreaseCount;
        },
        text2: 'durability'
    },

    //Clumsy and Hard Armor by Cube
    hardArmor: {
        keyword: 'Hard Armor',
        text: 'Enemy attacks use up',
        func: function (cont, obj) {
            return obj.custom.decreaseCount;
        },
        text2: 'durability'
    }
};
